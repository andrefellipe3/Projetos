import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DecimalFormat;

class ListaAlocacaoFlexivel {

    static class Celula {
        public Personagem elemento; // Elemento inserido na celula.
        public Celula prox; // Aponta a celula prox.

        /**
         * Construtor da classe.
         */
        public Celula() {

        }

        
        //Construtor da classe.
        public Celula(Personagem x) {
            this.elemento = x;
            this.prox = null;
        }
    }

    static class Lista {
        private Celula primeiro;
        private Celula ultimo;

        public Lista() {
            primeiro = new Celula();
            ultimo = primeiro;
        }

        
          //Insere um elemento na primeira posicao da lista.
        public void inserirInicio(Personagem x) {
            Celula tmp = new Celula(x);
            tmp.prox = primeiro.prox;
            primeiro.prox = tmp;
            if (primeiro == ultimo) {
                ultimo = tmp;
            }
            tmp = null;
        }

         //Insere um elemento na ultima posicao da lista.
        public void inserirFim(Personagem x) {
            ultimo.prox = new Celula(x);
            ultimo = ultimo.prox;
        }


        //Remove um elemento da primeira posicao da lista.
        public Personagem removerInicio() throws Exception {
            if (primeiro == ultimo) {
                throw new Exception("Erro ao remover (vazia)!");
            }
            Personagem resp = new Personagem();
            Celula tmp = primeiro;
            primeiro = primeiro.prox;
            resp = primeiro.elemento;
            tmp.prox = null;
            tmp = null;
            return resp;
        }

        // Remove um elemento da ultima posicao da lista.

        public Personagem removerFim() throws Exception {
            if (primeiro == ultimo) {
                throw new Exception("Erro ao remover (vazia)!");
            }
            Personagem resp = new Personagem();

            // Caminhar ate a penultima celula:
            Celula i;
            for (i = primeiro; i.prox != ultimo; i = i.prox)
                ;
            resp = ultimo.elemento;
            ultimo = i;
            i = ultimo.prox = null;

            return resp;
        }

        /**
         * Insere um elemento em uma posicao especifica considerando que o primeiro
         * elemento valido esta na posicao 0.
         */
        public void inserir(Personagem x, int pos) throws Exception {

            int tamanho = tamanho();

            if (pos < 0 || pos > tamanho) {
                throw new Exception("Erro ao inserir posicao (" + pos + " / tamanho = " + tamanho + ") invalida!");
            } else if (pos == 0) {
                inserirInicio(x);
            } else if (pos == tamanho) {
                inserirFim(x);
            } else {
                // Caminhar ate a posicao anterior a insercao
                Celula i = primeiro;
                for (int j = 0; j < pos; j++, i = i.prox)
                    ;
                Celula tmp = new Celula(x);
                tmp.prox = i.prox;
                i.prox = tmp;
                tmp = i = null;
            }
        }

        /**
         /* Remove um elemento de uma posicao especifica da lista considerando que o
         primeiro elemento valido esta na posicao 0.
         */ 
        public Personagem remover(int pos) throws Exception {
            Personagem resp = new Personagem();
            int tamanho = tamanho();

            if (primeiro == ultimo) {
                throw new Exception("Erro ao remover (vazia)!");

            } else if (pos < 0 || pos >= tamanho) {
                throw new Exception("Erro ao remover (posicao " + pos + " / " + tamanho + " invalida!");
            } else if (pos == 0) {
                resp = removerInicio();
            } else if (pos == tamanho - 1) {
                resp = removerFim();
            } else {
                // Caminhar ate a posicao anterior a insercao
                Celula i = primeiro;
                for (int j = 0; j < pos; j++, i = i.prox)
                    ;
                Celula tmp = i.prox;
                resp = tmp.elemento;
                i.prox = tmp.prox;
                tmp.prox = null;
                i = tmp = null;
            }

            return resp;
        }

        /**
         * Mostra os elementos da lista separados por espacos.
         */
        public void mostrar() {
            int count = 0;
            for (Celula i = primeiro.prox; i != null; i = i.prox) {
                System.out.print("[" + count + "] " + i.elemento + "\n");
                count++;
            }

        }

        /**
         * Calcula e retorna o tamanho, em numero de elementos, da lista.
         * 
         * @return resp int tamanho
         */
        public int tamanho() {
            int tamanho = 0;
            for (Celula i = primeiro; i != ultimo; i = i.prox, tamanho++)
                ;
            return tamanho;
        }
    }

    static class Personagem {
        private String nome;
        private int altura;
        private double peso;
        private String corDoCabelo;
        private String corDaPele;
        private String corDosOlhos;
        private String anoNascimento;
        private String genero;
        private String homeworld;

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public int getAltura() {
            return altura;
        }

        public void setAltura(int altura) {
            this.altura = altura;
        }

        public double getPeso() {
            return peso;
        }

        public void setPeso(double peso) {
            this.peso = peso;
        }

        public String getCorDoCabelo() {
            return corDoCabelo;
        }

        public void setCorDoCabelo(String corDoCabelo) {
            this.corDoCabelo = corDoCabelo;
        }

        public String getCorDaPele() {
            return corDaPele;
        }

        public void setCorDaPele(String corDaPele) {
            this.corDaPele = corDaPele;
        }

        public String getCorDosOlhos() {
            return corDosOlhos;
        }

        public void setCorDosOlhos(String corDosOlhos) {
            this.corDosOlhos = corDosOlhos;
        }

        public String getAnoNascimento() {
            return anoNascimento;
        }

        public void setAnoNascimento(String anoNascimento) {
            this.anoNascimento = anoNascimento;
        }

        public String getGenero() {
            return genero;
        }

        public void setGenero(String genero) {
            this.genero = genero;
        }

        public String getHomeworld() {
            return homeworld;
        }

        public void setHomeworld(String homeworld) {
            this.homeworld = homeworld;
        }

        public Personagem clone() {
            Personagem novo = new Personagem();
            novo.nome = this.nome;
            novo.altura = this.altura;
            novo.peso = this.peso;
            novo.corDoCabelo = this.corDoCabelo;
            novo.corDaPele = this.corDaPele;
            novo.corDosOlhos = this.corDosOlhos;
            novo.anoNascimento = this.anoNascimento;
            novo.genero = this.genero;
            novo.homeworld = this.homeworld;
            return novo;
        }

        public void ler(String nomeArquivo) throws Exception {
            FileReader file = new FileReader(nomeArquivo);
            BufferedReader buffer = new BufferedReader(file);
            String json = "";
            String line = buffer.readLine();
            while (line != null) {
                json += line;
                line = buffer.readLine();
            }

            buffer.close();
            file.close();

            String temp;
            temp = json.substring(json.indexOf("name") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            this.nome = temp;

            temp = json.substring(json.indexOf("height") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.altura = 0;
            else
                this.altura = Integer.parseInt(temp);

            temp = json.substring(json.indexOf("mass") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.peso = 0;
            else
                this.peso = Double.parseDouble(temp.replace(",", ""));

            temp = json.substring(json.indexOf("hair_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDoCabelo = temp;

            temp = json.substring(json.indexOf("skin_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDaPele = temp;

            temp = json.substring(json.indexOf("eye_color") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDosOlhos = temp;

            temp = json.substring(json.indexOf("birth_year") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.anoNascimento = temp;

            temp = json.substring(json.indexOf("gender") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            this.genero = temp;

            temp = json.substring(json.indexOf("homeworld") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.homeworld = temp;
        }

        public void imprimir() {
            System.out.println(toString());
        }

        public String toString() {
            DecimalFormat df = new DecimalFormat("#0.##");
            String resp = " ## " + nome + " ## " + altura + " ## ";
            resp += df.format(peso) + " ## " + corDoCabelo + " ## ";
            resp += corDaPele + " ## " + corDosOlhos + " ## ";
            resp += anoNascimento + " ## " + genero + " ## ";
            resp += homeworld + " ## ";
            return resp;
        }

        public void imprimirNome() {
            System.out.println(nome);
        }

    }// Fim da Classe Personagem

    public static boolean isFim(String s) {
        return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }

    public static String ISO88591toUTF8(String strISO) {
        try {
            byte[] isoBytes = strISO.getBytes("ISO-8859-1");
            return new String(isoBytes, "UTF-8");
        } catch (Exception e) {
            MyIO.println("ERRO: Ao converter!!");
        }
        return strISO;

    }

    public static void main(String[] args) {
        MyIO.setCharset("UTF-8");
        Personagem Character = new Personagem();
        String count;
        Lista lista = new Lista();
        int numEntrada = 0, y = 0;
        String[] entrada = new String[1000];
        do {
            entrada[numEntrada] = MyIO.readLine();
        } while (isFim(entrada[numEntrada++]) == false);
        numEntrada--;
        try {
            for (int i = 0; i < numEntrada; i++) {
                Character.ler(entrada[i]);
                lista.inserirFim(Character.clone());

            }
        } catch (Exception f) {
            MyIO.println("Exception Error Leitura");
        }
        count = MyIO.readLine();
        y = Integer.parseInt(count);

        // Limpar os vetores de string
        for (int i = 0; i < numEntrada; i++) {
            entrada[i] = "";
        }

        String tmp;
        // Fazendo a veficacao e alteracao
        for (int i = 0; i < y; i++) {
            entrada[i] = MyIO.readLine();

            // Inserir no Inicio
            if (entrada[i].charAt(0) == 'I' && entrada[i].charAt(1) == 'I') {
                try {
                    entrada[i] = entrada[i].replace("II ", "");
                    Character.ler(entrada[i]);
                    lista.inserirInicio(Character.clone());
                } catch (Exception a) {
                    MyIO.println("Exception Error InserirInicio");
                }
            }
            // Inserir numa posicao
            if (entrada[i].contains("I* ")) {
                entrada[i] = entrada[i].replace("I* ", "");
                tmp = "" + entrada[i].substring(0, 2);
                int numero = Integer.parseInt(tmp);
                entrada[i] = entrada[i].replace(" ", "");
                entrada[i] = entrada[i].substring(2);
                try {
                    Character.ler(entrada[i]);
                    lista.inserir(Character.clone(), numero);
                } catch (Exception b) {
                    MyIO.println("Exception Error InserirPosicao");
                }
            }
            // Inserir no Fim
            if (entrada[i].charAt(0) == 'I' && entrada[i].charAt(1) == 'F') {
                entrada[i] = entrada[i].replace("IF", "");
                entrada[i] = entrada[i].replace(" ", "");
                try {
                    Character.ler(entrada[i]);
                    lista.inserirFim(Character.clone());
                } catch (Exception c) {
                    MyIO.println("Exception Error InserirFim");
                }
            }

            // Remover no inicio
            if (entrada[i].charAt(0) == 'R' && entrada[i].charAt(1) == 'I') {
                try {
                    MyIO.println("(R) " + lista.removerInicio().nome);
                } catch (Exception d) {
                    MyIO.println("Exception Error RemoverInicio");
                }
            }

            // Remover posicao
            if (entrada[i].contains("R* ")) {
                entrada[i] = entrada[i].replace("R* ", "");
                int numero = Integer.parseInt(entrada[i]);
                try {
                    MyIO.println("(R) " + lista.remover(numero).nome);
                } catch (Exception e) {
                    MyIO.println("Exception Error RemoverPosicao");
                }
            }

            // Remover Fim
            if (entrada[i].charAt(0) == 'R' && entrada[i].charAt(1) == 'F') {
                entrada[i] = entrada[i].replace("RF", "");
                entrada[i] = entrada[i].replace(" ", "");
                try {
                    MyIO.println("(R) " + lista.removerFim().nome);
                } catch (Exception f) {
                    MyIO.println("Exception Error RemoverFim");
                }
                entrada[i] = "";
            }
        } // Fim teste e alteracao
        //Mostrar todos os elementos nas celulas
        lista.mostrar();
    }// Fim main
}
