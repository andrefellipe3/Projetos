#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#define bool short
#define true 1
#define false 0
#define equals(a, b) (((strcmp(a, b) == 0) ? true : false))
#define NUMENTRADA 1000
#define TAMLINHA 1000
#define MAXTAM 1000
#define TAMFILA 6

struct personagem
{
   char *nome;
   char *corDoCabelo;
   char *corDaPele;
   char *corDosOlhos;
   char *anoNascimento;
   char *genero;
   char *homeworld;
   int altura;
   double peso;
};
typedef struct personagem personagem;

//Lista
struct Lista
{
   personagem *array[MAXTAM];
   int n;
   int primeiro;
   int ultimo;
   float mediaAltura;
};
typedef struct Lista Lista;

bool isFim(char *palavra)
{
   return (strlen(palavra) >= 3 && palavra[0] == 'F' && palavra[1] == 'I' && palavra[2] == 'M');
}

personagem *remover(struct Lista *y)
{
   //validar remocao
   if ((y->primeiro == y->ultimo) || (y->n == 0))
   {
   
      printf("Erro ao remover!");
      exit(1);
   }

   personagem *resp = y->array[y->primeiro];
   y->primeiro =(y->primeiro + 1)%TAMFILA;
   y->n--;
   return (resp);
}

// Algoritmo de ordenacao
void bubbleSort(struct Lista* y,struct personagem *x) 
{
    personagem *auxiliar;
   for (int i = (y->n - 1); i > 0; i--) 
   {
      for (int j = 0; j < i; j++) 
      {
         if (strcmp(y->array[j]->anoNascimento,y->array[j + 1]->anoNascimento)>0) 
         {
             auxiliar = y->array[j + 1];
            y->array[j + 1] = y->array[j];
            y->array[j] = auxiliar;
         }
      }
   }
}

void construtor(struct personagem *z)
{
   z->nome = "";
   z->corDoCabelo = "";
   z->corDaPele = "";
   z->corDosOlhos = "";
   z->anoNascimento = "";
   z->genero = "";
   z->homeworld = "";
   z->peso = 0;
   z->altura = 0;
}

void imprimir(struct Lista *x, int i)
{
   printf(" ## %s ## %d ## %g ## %s ## %s ## %s ## %s ## %s ## %s ## \n",
          x->array[i]->nome, x->array[i]->altura, x->array[i]->peso, x->array[i]->corDoCabelo,
          x->array[i]->corDaPele, x->array[i]->corDosOlhos, x->array[i]->anoNascimento,
          x->array[i]->genero, x->array[i]->homeworld);
}

void mostrar(struct Lista *x)
{
   for (int i = 0; i < x->n; i++)
   {
      imprimir(x, i);
   }
}

void imprimirNome(struct personagem *y)
{
   printf("(R) %s\n", y->nome);
}

//Clone
personagem *clone(struct personagem *y)
{
   personagem *copia = (personagem *)malloc(sizeof(personagem));
   //Malloc
   copia->nome = (char *)malloc(100 * sizeof(char));
   copia->corDoCabelo = (char *)malloc(100 * sizeof(char));
   copia->corDaPele = (char *)malloc(100 * sizeof(char));
   copia->corDosOlhos = (char *)malloc(100 * sizeof(char));
   copia->anoNascimento = (char *)malloc(100 * sizeof(char));
   copia->genero = (char *)malloc(100 * sizeof(char));
   copia->homeworld = (char *)malloc(100 * sizeof(char));
   //Salvando as String na copia
   strcpy(copia->nome, y->nome);
   strcpy(copia->corDoCabelo, y->corDoCabelo);
   strcpy(copia->corDaPele, y->corDaPele);
   strcpy(copia->corDosOlhos, y->corDosOlhos);
   strcpy(copia->anoNascimento, y->anoNascimento);
   strcpy(copia->genero, y->genero);
   strcpy(copia->homeworld, y->homeworld);
   copia->altura = y->altura;
   copia->peso = y->peso;
   return copia;
}

void ler(char *palavra, personagem *y)
{
   construtor(y);
   char tmp[TAMLINHA];
   char info[TAMLINHA];
   char *aux;
   int tamanho = 0, i = 0, x = 0, z = 0;
   tamanho = strlen(palavra) - 1;
   //Formatando a entrada no arquivo
   strcpy(info, palavra);
   info[tamanho] = '\0';
   FILE *arquivo = fopen(info, "r");
   if (arquivo != NULL)
   {
      fgets(tmp, TAMLINHA, arquivo);
      fclose(arquivo);
      //Nome
      aux = strstr(tmp, "name");
      i = aux - tmp + 8;
      char NomeFormatado[TAMLINHA];
      while (tmp[i] != '\'')
      {
         NomeFormatado[x] = tmp[i];
         i++;
         x++;
      }
      NomeFormatado[x] = '\0';
      y->nome = NomeFormatado;

      //Altura
      aux = strstr(tmp, "height");
      i = aux - tmp + 10;
      char AlturaFormatado[TAMLINHA];
      x = 0;
      while (tmp[i] != '\'')
      {
         AlturaFormatado[x] = tmp[i];
         i++;
         x++;
      }
      AlturaFormatado[x] = '\0';
      y->altura = atoi(AlturaFormatado);

      //PESO
      aux = strstr(tmp, "mass");
      i = aux - tmp + 8;
      char PesoFormatado[TAMLINHA];
      x = 0;
      while (tmp[i] != '\'')
      {
         PesoFormatado[x] = tmp[i];
         i++;
         x++;
      }
      PesoFormatado[x] = '\0';
      y->peso = atof(PesoFormatado);

      //CorDoCabelo
      aux = strstr(tmp, "hair_color");
      i = aux - tmp + 14;
      char CorDoCabeloFormatado[TAMLINHA];
      x = 0;
      while (tmp[i] != '\'')
      {
         CorDoCabeloFormatado[x] = tmp[i];
         i++;
         x++;
      }
      CorDoCabeloFormatado[x] = '\0';
      y->corDoCabelo = CorDoCabeloFormatado;

      //CorDaPele
      aux = strstr(tmp, "skin_color");
      i = aux - tmp + 14;
      char CorDaPeleFormatado[TAMLINHA];
      x = 0;
      while (tmp[i] != '\'')
      {
         CorDaPeleFormatado[x] = tmp[i];
         i++;
         x++;
      }
      CorDaPeleFormatado[x] = '\0';
      y->corDaPele = CorDaPeleFormatado;

      //corDosOlhos
      aux = strstr(tmp, "eye_color");
      i = aux - tmp + 13;
      char CorDosOlhosFormatado[TAMLINHA];
      x = 0;
      while (tmp[i] != '\'')
      {
         CorDosOlhosFormatado[x] = tmp[i];
         i++;
         x++;
      }
      CorDosOlhosFormatado[x] = '\0';
      y->corDosOlhos = CorDosOlhosFormatado;

      //anoNascimento
      aux = strstr(tmp, "birth_year");
      i = aux - tmp + 14;
      char anoNascimentoFormatado[TAMLINHA];
      x = 0;
      while (tmp[i] != '\'')
      {
         anoNascimentoFormatado[x] = tmp[i];
         i++;
         x++;
      }
      anoNascimentoFormatado[x] = '\0';
      y->anoNascimento = anoNascimentoFormatado;

      //genero
      aux = strstr(tmp, "gender");
      i = aux - tmp + 10;
      char generoFormatado[TAMLINHA];
      x = 0;
      while (tmp[i] != '\'')
      {
         generoFormatado[x] = tmp[i];
         i++;
         x++;
      }
      generoFormatado[x] = '\0';
      y->genero = generoFormatado;

      //homeworld
      aux = strstr(tmp, "homeworld");
      i = aux - tmp + 13;
      char homeworldFormatado[TAMLINHA];
      x = 0;
      while (tmp[i] != '\'')
      {
         homeworldFormatado[x] = tmp[i];
         i++;
         x++;
      }
      homeworldFormatado[x] = '\0';
      y->homeworld = homeworldFormatado;
   }
}

void method01()
{
   char palavra[NUMENTRADA][TAMLINHA];
   char palavra1[NUMENTRADA][TAMLINHA];
   int entrada = 0, i = 0, y = 0, z = 0;
   char pos[80];
   personagem *Personagem;
   Lista *lista;
   Personagem = (personagem *)malloc(sizeof(personagem));
   lista = (Lista *)malloc(sizeof(Lista));
   lista->n = 0;
   lista->primeiro = 0; 
   lista->ultimo = 0;
   do
   {
      //Entrada padrao
      fgets(palavra[entrada], TAMLINHA, stdin);
   } while (isFim(palavra[entrada++]) == false);
   entrada--;
   for (i = 0; i < entrada; i++)
   {
      ler(palavra[i],Personagem);
      Personagem = clone(Personagem);
      lista->array[i] = clone(Personagem);
      lista->n++;
   }
   bubbleSort(lista,Personagem);
   mostrar(lista);

}

int main()
{
   method01();
   return 0;
}
