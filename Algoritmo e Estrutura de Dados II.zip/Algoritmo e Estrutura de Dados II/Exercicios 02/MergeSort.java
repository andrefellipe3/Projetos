import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DecimalFormat;

class MergeSort
{ 

static class Lista
   {
	  private Personagem array [];
	  private int n,cmp,mov;
   
      public Lista () 
      {
         this(6);
      }
   
      public Lista (int tam)
      {
         array = new Personagem[tam];
         n = 0;
      }
   
      public void inserirInicio(Personagem x) throws Exception {

		//validar insercao
		if(n >= array.length){
		   throw new Exception("Erro ao inserir!");
		} 

		//levar elementos para o fim do array
		for(int i = n; i > 0; i--){
		   array[i] = array[i-1];
		}

		array[0] = x;
		n++;
	 }

	 public void inserirFim(Personagem x) throws Exception {

		//validar insercao
		if(n >= array.length){
		   throw new Exception("Erro ao inserir!");
		}

		array[n] = x;
		n++;
	 }

	 public void inserir(Personagem x, int pos) throws Exception {

	 //validar insercao
	 if(n == array.length || pos < 0 || pos > n){
		   throw new Exception("Erro ao inserir!");
		}

		//levar elementos para o fim do array
		for(int i = n; i > pos; i--){
		   array[i] = array[i-1];
		}

		array[pos] = x;
		n++;
	 }

	 public Personagem removerInicio() throws Exception {

		//validar remocao
		if (n == 0) {
		   throw new Exception("Erro ao remover!");
		}

		Personagem resp = array[0];
		n--;

		for(int i = 0; i < n; i++){
		   array[i] = array[i+1];
		}

		return resp;
	 }

	 public Personagem removerFim() throws Exception {

		// validar remocao
		if (n == 0) {
		   throw new Exception("Erro ao remover!");
		}

		return array[--n];
	 }

	 public Personagem remover(int pos) throws Exception {

		//validar remocao
		if (n == 0 || pos < 0 || pos >= n) {
		   throw new Exception("Erro ao remover!");
		}

		Personagem resp = array[pos];
		n--;

		for(int i = pos; i < n; i++){
		   array[i] = array[i+1];
		}

		return resp;
	 }

    /**
    * Troca o conteudo de duas posicoes do array
    * @param i int primeira posicao
    * @param j int segunda posicao
    */
   public void swap(int i, int j) 
   {
    Personagem temp = new Personagem();
    temp = array[i];
    array[i] = array[j];
    array[j] = temp;
 }

 
     /**
  * Algoritmo de ordenacao por selecao.
  */
 public void selecao()
 {
    int menor;
    for (int i = 0; i < n; i++) 
    {
        menor = i;
       for (int j = (i + 1); j < n; j++)
       {
          if (array[j].nome.compareTo(array[menor].nome)< 0)
          {
             menor = j;
          }
          if(menor != i)
          {
          swap(menor, i);
          }
       }
       
    }
 }

 void merge(int l, int m, int r) 
    { 
		int counttmp = 0;
        int n1 = m - l + 1; 
        int n2 = r - m; 
  
		Personagem L[] = new Personagem [n1]; 
		Personagem R[] = new Personagem [n2]; 

        for (int i=0; i<n1; ++i) 
            L[i] = array[l + i]; 
        for (int j=0; j<n2; ++j) 
            R[j] = array[m + 1+ j]; 
  
        int i = 0, j = 0; 

        int k = l; 
        while (i < n1 && j < n2) 
        { 
            if (L[i].homeworld.compareTo(R[j].homeworld)<0) 
            { 
                array[k] = L[i]; 
                i++; 
            } 
            else
            { 
                array[k] = R[j]; 
                j++; 
            } 
            k++; 
        } 

        while (i < n1) 
        { 
            array[k] = L[i]; 
            i++; 
            k++; 
        } 

        while (j < n2) 
        { 
            array[k] = R[j]; 
            j++; 
            k++; 
		} 
		
	//Desempatando pelo nome
	for (int count = 1; count < n; count++)
   {
    if(array[counttmp].homeworld.compareTo(array[count].homeworld)==0);
    {
    for (int tmpvar = counttmp+1; tmpvar < n; tmpvar++)
    {
    if(array[counttmp].homeworld.compareTo(array[tmpvar].homeworld)==0)
    {
    if (array[counttmp].nome.compareTo(array[tmpvar].nome)>0)
    {
    swap(counttmp,tmpvar);
    }    
    }
    }
    }
    counttmp++;
   }
	}
  
    void sort(int l, int r) 
    { 
        if (l < r) 
        { 
            int m = (l+r)/2;  
            sort( l, m); 
            sort( m+1, r); 
            merge(l, m, r); 
        } 
    } 


   }//Fim Lista

static class Personagem 
{
	private String nome;
	private int altura;
	private double peso;
	private String corDoCabelo;
	private String corDaPele;
	private String corDosOlhos;
	private String anoNascimento;
	private String genero;
	private String homeworld;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public String getCorDoCabelo() {
		return corDoCabelo;
	}

	public void setCorDoCabelo(String corDoCabelo) {
		this.corDoCabelo = corDoCabelo;
	}

	public String getCorDaPele() {
		return corDaPele;
	}

	public void setCorDaPele(String corDaPele) {
		this.corDaPele = corDaPele;
	}

	public String getCorDosOlhos() {
		return corDosOlhos;
	}

	public void setCorDosOlhos(String corDosOlhos) {
		this.corDosOlhos = corDosOlhos;
	}

	public String getAnoNascimento() {
		return anoNascimento;
	}

	public void setAnoNascimento(String anoNascimento) {
		this.anoNascimento = anoNascimento;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

	public String getHomeworld() {
		return homeworld;
	}

	public void setHomeworld(String homeworld) {
		this.homeworld = homeworld;
	}

	public Personagem clone() {
		Personagem novo = new Personagem();
		novo.nome = this.nome;
		novo.altura = this.altura;
		novo.peso = this.peso;
		novo.corDoCabelo = this.corDoCabelo;
		novo.corDaPele = this.corDaPele;
		novo.corDosOlhos = this.corDosOlhos;
		novo.anoNascimento = this.anoNascimento;
		novo.genero = this.genero;
		novo.homeworld = this.homeworld;
		return novo;
	}

	public void ler(String nomeArquivo) throws Exception 
	{
		FileReader file = new FileReader(nomeArquivo);
		BufferedReader buffer = new BufferedReader(file);
		String json = "";
		String line = buffer.readLine();
		while (line != null) {
			json += line;
			line = buffer.readLine();
		}

		buffer.close();
		file.close();

		String temp;
		temp = json.substring(json.indexOf("name") + 8);
		temp = temp.substring(0, temp.indexOf("',"));
		this.nome = temp;

		temp = json.substring(json.indexOf("height") + 10);
		temp = temp.substring(0, temp.indexOf("',"));
		if (temp.equals("unknown"))
			this.altura = 0;
		else
			this.altura = Integer.parseInt(temp);

		temp = json.substring(json.indexOf("mass") + 8);
		temp = temp.substring(0, temp.indexOf("',"));
		if (temp.equals("unknown"))
			this.peso = 0;
		else
			this.peso = Double.parseDouble(temp.replace(",", ""));

		temp = json.substring(json.indexOf("hair_color") + 14);
		temp = temp.substring(0, temp.indexOf("',"));
		this.corDoCabelo = temp;

		temp = json.substring(json.indexOf("skin_color") + 14);
		temp = temp.substring(0, temp.indexOf("',"));
		this.corDaPele = temp;

		temp = json.substring(json.indexOf("eye_color") + 13);
		temp = temp.substring(0, temp.indexOf("',"));
		this.corDosOlhos = temp;

		temp = json.substring(json.indexOf("birth_year") + 14);
		temp = temp.substring(0, temp.indexOf("',"));
		this.anoNascimento = temp;

		temp = json.substring(json.indexOf("gender") + 10);
		temp = temp.substring(0, temp.indexOf("',"));
		this.genero = temp;

		temp = json.substring(json.indexOf("homeworld") + 13);
		temp = temp.substring(0, temp.indexOf("',"));
		this.homeworld = temp;
	}
	
          
		 public void imprimir() 
		 {
		System.out.println(toString());
	}

	public String toString() 
	{
		DecimalFormat df = new DecimalFormat("#0.##");
		String resp = " ## " + nome + " ## " + altura + " ## ";
		resp += df.format(peso) + " ## " + corDoCabelo + " ## ";
		resp += corDaPele + " ## " + corDosOlhos + " ## ";
		resp += anoNascimento + " ## " + genero + " ## ";
		resp += homeworld + " ## ";
		return resp;
	}

	public void imprimirNome() 
	{
		System.out.println(nome);
	}

	public void imprimirLista(int count) 
		 {
		MyIO.println("["+count+"] "+toString());
	    }

	

}//Fim da Classe Personagem

public static boolean isFim (String s)
{
   return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
}

public static String ISO88591toUTF8(String strISO) 
{
	try {
	   byte[] isoBytes = strISO.getBytes("ISO-8859-1");
	   return new String(isoBytes, "UTF-8");
	} catch (Exception e) {
	   MyIO.println("ERRO: Ao converter!!");
	}
	return strISO;
       
} 

public static void main (String[] args )
{
      MyIO.setCharset("UTF-8");
      int comp = 0, mov = 0;
	 // long tempoInicial = System.currentTimeMillis();
	  Personagem Character = new Personagem();
	  Lista lista = new Lista(1000);
	  int numEntrada = 0;
      String [] entrada = new String [1000];
      do
      {
         entrada[numEntrada] = MyIO.readLine();
      }
      while(isFim(entrada[numEntrada++]) == false);
      numEntrada--; 
	  try
	{  
	  for ( int i = 0; i < numEntrada; i++)
      {
		 Character.ler(entrada[i]);
		 lista.inserirFim(Character.clone());
	  }
	}
	catch (Exception f) 
	{
		MyIO.println("Exception Error Leitura");
	}
	comp = lista.cmp;
	mov = lista.mov;
	long tempoInicial = System.currentTimeMillis();
	lista.sort(0, lista.n-1); 
	long tempoFinal = System.currentTimeMillis();
	//Limpar os vetores de string
	for (int i = 0; i < numEntrada; i++)
	{
	   entrada[i] = "";
	}
    for ( int i = 0; i < lista.n; i++)
      {
        try {
         Character = lista.array[i];
         Character.imprimir();
        }catch(Exception f){
		MyIO.println("Erro na impressao");
        }
	  }


Arq.openWrite("matricula_mergesort.txt");
Arq.println("637084\t"+"Numero de comparacoes: "+ comp +"\t Numero de movimentacao: "+mov+"\t Tempo de Execucao: " + (tempoFinal - tempoInicial));
Arq.close();
}//Fim main
}	