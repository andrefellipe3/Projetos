class Personagem
{
   private String nome,corDoCabelo,corDaPele,corDosOlhos,anoNascimento,genero,homeworld;
   private int altura = 0;
   private double peso = 0;
   
   public static boolean isFim (String s)
   {
      return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
   }
   
   public double getPeso() 
   {
      return peso;
   }
  
   public void setPeso(double peso) 
   {
      this.peso = peso;
   }
  
   public int getAltura() 
   {
      return altura;
   }
  
   public void setAltura(int altura) 
   {
      this.altura = altura;
   }
   
   public String getNome() 
   {
      return nome;
   }
  
   public void setNome(String nome) 
   {
      this.nome = nome;
   }
   
   public String getCorDoCabelo() 
   {
      return corDoCabelo;
   }
  
   public void setCorDoCabelo(String corDoCabelo) 
   {
      this.corDoCabelo = corDoCabelo;
   }
   
   public String getCorDaPele() 
   {
      return corDaPele;
   }
  
   public void setCorDaPele(String corDaPele) 
   {
      this.corDaPele = corDaPele;
   }
   
   public String getCorDosOlhos() 
   {
      return corDosOlhos;
   }
  
   public void setCorDosOlhos(String corDosOlhos) 
   {
      this.corDosOlhos = corDosOlhos;
   }

   public String getAnoNascimento()
   {
      return anoNascimento;
   }
   
   public void setAnoNascimento(String anoNascimento)
   {
      this.anoNascimento = anoNascimento;
   }
   
   public String getGenero()
   {
      return genero;
   }
   
   public void setGenero(String genero)
   {
      this.genero = genero;
   }
   
   public String getHomeworld()
   {
      return homeworld;
   }
   
   public void setHomeworld(String homeworld)
   {
      this.homeworld = homeworld;
   }
   
   public Personagem ( )
   {
      nome = corDoCabelo = corDaPele = corDosOlhos = anoNascimento = genero = homeworld = "";
      altura = 0;
      peso = 0;
   }
   
   public Personagem clone ( )
   {
      Personagem clone = new Personagem ( );
      clone.nome = this.nome;
      clone.corDoCabelo = this.corDoCabelo;
      clone.corDaPele = this.corDaPele;
      clone.corDosOlhos = this.corDosOlhos;
      clone.anoNascimento = this.anoNascimento;
      clone.genero = this.genero;
      clone.homeworld = this.homeworld;
      clone.altura = this.altura;
      clone.peso = this.peso;
      return clone;  
   }
   
   //Metodo para ler os dados do arquivo e organizar
   public void ler (String urlArq )
   {
      int altura = 0;
      Arq.openRead(urlArq);
      String str = Arq.readLine();
      Arq.close();
      str = str.replace(",","");
      str = str.replace("{","");
      str = str.replace("'","");
      String [] tmp = str.split("films:");
      str = tmp[0];
      str = str.replace("name:","");
      str = str.replace("height","");
      str = str.replace("mass","");
      str = str.replace("hair_color","");
      str = str.replace("skin_color","");
      str = str.replace("eye_color","");
      str = str.replace("birth_year","");
      str = str.replace("gender","");
      str = str.replace("homeworld","");
      String [] informacoes = new String [10000];
      informacoes =  str.split(":");
      informacoes[1] = informacoes[1].replace (" ","");
      informacoes[2] = informacoes[2].replace (" ","");
      setNome(informacoes[0]);
       //Convertendo a string altura para inteiro
      if (informacoes[1].charAt(0) == 'u')
      {
         altura = 0;
         setAltura(altura);
      }
      else
      {
         altura = Integer.parseInt(informacoes[1]);
         setAltura(altura);
      }
       //Convertendo a string peso pra double
      if (informacoes[2].charAt(0) == 'u' && informacoes[2].charAt(1) == 'n' && informacoes[2].charAt(2) == 'k')
      {
         peso = 0;
         setPeso(peso);
      }
      else
      {
         double peso = Double.parseDouble(informacoes[2]);
         setPeso(peso);
      }
      setCorDoCabelo(informacoes[3]);
      setCorDaPele(informacoes[4]);
      setCorDosOlhos(informacoes[5]);
      setAnoNascimento(informacoes[6]);
      setGenero(informacoes[7]);
      setHomeworld(informacoes[8]);     
   }
   //Metodo pra imprimir
   public void imprimir ()
   {
      String PesoConvertido="";
      String nome,corDoCabelo,corDaPele,corDosOlhos,anoNascimento,genero,homeworld;
      int altura = 0;
      double peso = 0;
      nome = this.nome;
      corDoCabelo = this.corDoCabelo;
      corDaPele = this.corDaPele;
      corDosOlhos = this.corDosOlhos;
      anoNascimento = this.anoNascimento;
      genero = this.genero;
      homeworld = this.homeworld;
      altura = this.altura;
      peso = this.peso;
      PesoConvertido = ""+peso;
      PesoConvertido = PesoConvertido.replace(".0","");
      MyIO.print(" ##"+nome);
      MyIO.print("## "+altura);
      MyIO.print(" ## "+PesoConvertido);
      MyIO.print(" ##"+corDoCabelo);
      MyIO.print("##"+corDaPele);
      MyIO.print("##"+corDosOlhos);
      MyIO.print("##"+anoNascimento);
      MyIO.print("##"+genero);
      MyIO.print("##"+homeworld + "##\n");
   }
   
   
   public static void main (String[] args )
   {
      MyIO.setCharset("UTF-8");
      Personagem Character;
      Character = new Personagem();
      int numEntrada = 0;
      String [] entrada = new String [1000];
      do
      {
         entrada[numEntrada] = MyIO.readLine();
      }
      while(isFim(entrada[numEntrada++]) == false);
      numEntrada--;   
      for ( int i = 0; i < numEntrada; i++)
      {
         Character.ler(entrada[i]);
         Character.imprimir();
      
      }
   }
}