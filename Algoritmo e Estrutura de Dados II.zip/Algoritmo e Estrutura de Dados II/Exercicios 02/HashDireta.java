import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DecimalFormat;

class HashDireta {
    public static int mov,comp = 0;

    public static class Hash {
        Personagem tabela[];
        int m1;
        int m2; 
        int m, reserva;
     
        public Hash (){
           this(21, 9);
        }
     
        public Hash (int m1, int m2){
           this.m1 = m1;
           this.m2 =  m2;
           this.m = m1 + m2;
           this.tabela = new Personagem [this.m];
           for(int i = 0; i < m; i++){
              tabela[i] = null;
           }
        }
     
        public int h(Personagem elemento){
           return elemento.altura % m1;
        }
     
        public boolean inserir (Personagem elemento){
           boolean resp = false;
     
           if(elemento != null){
               comp++;
     
              int pos = h(elemento);
     
              if(tabela[pos] == null){
                  comp++;
                 tabela[pos] = elemento;
                 resp = true;
     
              } else if (reserva < m2){
                  comp += 2;
                 tabela[m1 + reserva] = elemento;
                 reserva++;
                 resp = true;
              }
           }
     
           return resp;
        }
     
        public boolean pesquisar (String elemento){
            MyIO.print(elemento);
           boolean resp = false;
           for(int i = 0; i < m; i++)
           {
           if (tabela[i] != null && (tabela[i].nome.equals(elemento)))
           {
           return resp = true;    
           }
        }
        return resp;
        }
    }

    static class Personagem {
        private String nome;
        private int altura;
        private double peso;
        private String corDoCabelo;
        private String corDaPele;
        private String corDosOlhos;
        private String anoNascimento;
        private String genero;
        private String homeworld;

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public int getAltura() {
            return altura;
        }

        public void setAltura(int altura) {
            this.altura = altura;
        }

        public double getPeso() {
            return peso;
        }

        public void setPeso(double peso) {
            this.peso = peso;
        }

        public String getCorDoCabelo() {
            return corDoCabelo;
        }

        public void setCorDoCabelo(String corDoCabelo) {
            this.corDoCabelo = corDoCabelo;
        }

        public String getCorDaPele() {
            return corDaPele;
        }

        public void setCorDaPele(String corDaPele) {
            this.corDaPele = corDaPele;
        }

        public String getCorDosOlhos() {
            return corDosOlhos;
        }

        public void setCorDosOlhos(String corDosOlhos) {
            this.corDosOlhos = corDosOlhos;
        }

        public String getAnoNascimento() {
            return anoNascimento;
        }

        public void setAnoNascimento(String anoNascimento) {
            this.anoNascimento = anoNascimento;
        }

        public String getGenero() {
            return genero;
        }

        public void setGenero(String genero) {
            this.genero = genero;
        }

        public String getHomeworld() {
            return homeworld;
        }

        public void setHomeworld(String homeworld) {
            this.homeworld = homeworld;
        }

        public Personagem clone() {
            Personagem novo = new Personagem();
            novo.nome = this.nome;
            novo.altura = this.altura;
            novo.peso = this.peso;
            novo.corDoCabelo = this.corDoCabelo;
            novo.corDaPele = this.corDaPele;
            novo.corDosOlhos = this.corDosOlhos;
            novo.anoNascimento = this.anoNascimento;
            novo.genero = this.genero;
            novo.homeworld = this.homeworld;
            return novo;
        }

        public void ler(String nomeArquivo) throws Exception {
            FileReader file = new FileReader(nomeArquivo);
            BufferedReader buffer = new BufferedReader(file);
            String json = "";
            String line = buffer.readLine();
            while (line != null) {
                json += line;
                line = buffer.readLine();
            }

            buffer.close();
            file.close();

            String temp;
            temp = json.substring(json.indexOf("name") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            this.nome = temp;

            temp = json.substring(json.indexOf("height") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.altura = 0;
            else
                this.altura = Integer.parseInt(temp);

            temp = json.substring(json.indexOf("mass") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.peso = 0;
            else
                this.peso = Double.parseDouble(temp.replace(",", ""));

            temp = json.substring(json.indexOf("hair_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDoCabelo = temp;

            temp = json.substring(json.indexOf("skin_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDaPele = temp;

            temp = json.substring(json.indexOf("eye_color") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDosOlhos = temp;

            temp = json.substring(json.indexOf("birth_year") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.anoNascimento = temp;

            temp = json.substring(json.indexOf("gender") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            this.genero = temp;

            temp = json.substring(json.indexOf("homeworld") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.homeworld = temp;
        }

        public void imprimir() {
            System.out.println(toString());
        }

        public String toString() {
            DecimalFormat df = new DecimalFormat("#0.##");
            String resp = " ## " + nome + " ## " + altura + " ## ";
            resp += df.format(peso) + " ## " + corDoCabelo + " ## ";
            resp += corDaPele + " ## " + corDosOlhos + " ## ";
            resp += anoNascimento + " ## " + genero + " ## ";
            resp += homeworld + " ## ";
            return resp;
        }

        public void imprimirNome() {
            System.out.println(nome);
        }

    }// Fim da Classe Personagem

    public static boolean isFim(String s) {
        return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }

    public static String ISO88591toUTF8(String strISO) {
        try {
            byte[] isoBytes = strISO.getBytes("ISO-8859-1");
            return new String(isoBytes, "UTF-8");
        } catch (Exception e) {
            MyIO.println("ERRO: Ao converter!!");
        }
        return strISO;

    }

    public static void main(String[] args) {
        long tempoInicial = System.currentTimeMillis();
        boolean resp;
        Personagem Character = new Personagem();
        Hash hash = new Hash();
        int numEntrada = 0;
        String[] entrada = new String[1000];
        String[] nomes = new String[1000];
        do {
            entrada[numEntrada] = MyIO.readLine();
        } while (isFim(entrada[numEntrada++]) == false);
        numEntrada--;
        try {
            for (int i = 0; i < numEntrada; i++) {
                Character.ler(entrada[i]);
                hash.inserir(Character.clone());
            }
        } catch (Exception f) {
            MyIO.println("Exception Error Leitura");
        }
        numEntrada = 0;
        // Lendo os nomes
        do {
            nomes[numEntrada] = MyIO.readLine();
        } while (isFim(nomes[numEntrada++]) == false);
        numEntrada--;
        // Verificando se os nomes existem na arvore
        
        for (int i = 0; i < numEntrada; i++) {
            resp = hash.pesquisar(nomes[i]);
            if (resp == true) {
                MyIO.println(" SIM");
            } else {
                MyIO.println(" NÃO");
            }
        }
        long tempoFinal = System.currentTimeMillis();
        Arq.openWrite("matrícula_hashReserva.txt");
        Arq.println("637084\t"+"Numero de comparacoes: " + comp+ "\t Tempo de Execucao: " + (tempoFinal - tempoInicial));
        Arq.close();

        // Mostrar todos os elementos nas celulas
    }// Fim main
}
