class ListaTelefonica 
{

public static void main(String[] args)
{
int economizar = 0,n = 0,i = 0;
String [] palavra = new String [1000];
String tmp;
do
{
n = 0;
n = MyIO.readInt();
tmp = MyIO.readString();
for ( i = 1; i < n; i++)
{
palavra[i] = MyIO.readString();
for( int x = 0; x < tmp.length(); x++)
{
if(palavra[i].charAt(x) == tmp.charAt(x))
{
economizar++;
}
}
}
MyIO.println(economizar);
economizar = 0;
}while(n != 0);
}
}
