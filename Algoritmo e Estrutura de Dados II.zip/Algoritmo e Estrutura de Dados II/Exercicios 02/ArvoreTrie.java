import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DecimalFormat;

class ArvoreTrie {
    public static int mov,comp = 0;
    public static boolean resp = false;


    static class No {
        public Personagem personagem;
        public No esq, dir;

        /**
         * Construtor da classe.
         * 
         * @param elemento Conteudo do no.
         * @param esq      No da esquerda.
         * @param dir      No da direita.
         */
        public No(Personagem personagem, No esq, No dir) {
            this.personagem = personagem;
            this.esq = esq;
            this.dir = dir;
        }

        public No(Personagem personagem) {
            this(personagem, null, null);
        }

        public No() {

        }
    }// Fim No

    public static class Arvore {
        private No raiz;

        public Arvore() {
            raiz = null;
        }

        public void inserir(Personagem personagem) throws Exception {
            raiz = inserir(raiz, personagem);
        }

        private No inserir(No no, Personagem personagem) throws Exception {
            comp++;
            if (no == null) {
                no = new No(personagem);
            }

            else if (personagem.nome.compareTo(no.personagem.nome) < 0) {
                no.esq = inserir(no.esq, personagem);
                comp += 1;
            } 
            else if (personagem.nome.compareTo(no.personagem.nome) > 0) {
                no.dir = inserir(no.dir, personagem);
                comp += 2;
            } 
            else {
                throw new Exception("Erro ao inserir");
            }
            return no;
        }

        public void pesquisarNome(String nome) {
            pesquisarNome(raiz, nome);
        }

        private void pesquisarNome(No no, String nome) {
            if (no == null) {
                ;
            } else if (nome.equals(no.personagem.nome)) {
                resp = true;

            } else if (nome.compareTo(no.personagem.nome) < 0) {
                 pesquisarNome(no.esq, nome);

            } else {
                 pesquisarNome(no.dir, nome);
            }
           
        }
    }

     //Arvore2--------------------------------------------------------------------------------------------------------------------------------------
     
     static class No2 {
        public Personagem personagem;
        public No2 esq, dir;

        /**
         * Construtor da classe.
         * 
         * @param elemento Conteudo do no.
         * @param esq      No da esquerda.
         * @param dir      No da direita.
         */
        public No2(Personagem personagem, No2 esq, No2 dir) {
            this.personagem = personagem;
            this.esq = esq;
            this.dir = dir;
        }

        public No2(Personagem personagem) {
            this(personagem, null, null);
        }

        public No2() {

        }
    }// Fim No

    public static class Arvore2 {
        private No2 raiz;

        public Arvore2() {
            raiz = null;
        }

        public void inserir2(Personagem personagem) throws Exception {
            raiz = inserir2(raiz, personagem);
        }

        private No2 inserir2(No2 no, Personagem personagem) throws Exception {
            comp++;
            if (no == null) {
                no = new No2(personagem);
            }

            else if (personagem.nome.compareTo(no.personagem.nome) < 0) {
                no.esq = inserir2(no.esq, personagem);
                comp += 1;
            } 
            else if (personagem.nome.compareTo(no.personagem.nome) > 0) {
                no.dir = inserir2(no.dir, personagem);
                comp += 2;
            } 
            else {
                throw new Exception("Erro ao inserir");
            }
            return no;
        }

        public void pesquisarNome2(String nome) {
            pesquisarNome2(raiz, nome);
        }

        private void pesquisarNome2(No2 no, String nome) {
            if (no == null) {
                ;
            } else if (nome.equals(no.personagem.nome)) {
                resp = true;

            } else if (nome.compareTo(no.personagem.nome) < 0) {
                 pesquisarNome2(no.esq, nome);

            } else {
                 pesquisarNome2(no.dir, nome);
            }
           
        }

    }

    static class Personagem {
        private String nome;
        private int altura;
        private double peso;
        private String corDoCabelo;
        private String corDaPele;
        private String corDosOlhos;
        private String anoNascimento;
        private String genero;
        private String homeworld;

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public int getAltura() {
            return altura;
        }

        public void setAltura(int altura) {
            this.altura = altura;
        }

        public double getPeso() {
            return peso;
        }

        public void setPeso(double peso) {
            this.peso = peso;
        }

        public String getCorDoCabelo() {
            return corDoCabelo;
        }

        public void setCorDoCabelo(String corDoCabelo) {
            this.corDoCabelo = corDoCabelo;
        }

        public String getCorDaPele() {
            return corDaPele;
        }

        public void setCorDaPele(String corDaPele) {
            this.corDaPele = corDaPele;
        }

        public String getCorDosOlhos() {
            return corDosOlhos;
        }

        public void setCorDosOlhos(String corDosOlhos) {
            this.corDosOlhos = corDosOlhos;
        }

        public String getAnoNascimento() {
            return anoNascimento;
        }

        public void setAnoNascimento(String anoNascimento) {
            this.anoNascimento = anoNascimento;
        }

        public String getGenero() {
            return genero;
        }

        public void setGenero(String genero) {
            this.genero = genero;
        }

        public String getHomeworld() {
            return homeworld;
        }

        public void setHomeworld(String homeworld) {
            this.homeworld = homeworld;
        }

        public Personagem clone() {
            Personagem novo = new Personagem();
            novo.nome = this.nome;
            novo.altura = this.altura;
            novo.peso = this.peso;
            novo.corDoCabelo = this.corDoCabelo;
            novo.corDaPele = this.corDaPele;
            novo.corDosOlhos = this.corDosOlhos;
            novo.anoNascimento = this.anoNascimento;
            novo.genero = this.genero;
            novo.homeworld = this.homeworld;
            return novo;
        }

        public void ler(String nomeArquivo) throws Exception {
            FileReader file = new FileReader(nomeArquivo);
            BufferedReader buffer = new BufferedReader(file);
            String json = "";
            String line = buffer.readLine();
            while (line != null) {
                json += line;
                line = buffer.readLine();
            }

            buffer.close();
            file.close();

            String temp;
            temp = json.substring(json.indexOf("name") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            this.nome = temp;

            temp = json.substring(json.indexOf("height") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.altura = 0;
            else
                this.altura = Integer.parseInt(temp);

            temp = json.substring(json.indexOf("mass") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.peso = 0;
            else
                this.peso = Double.parseDouble(temp.replace(",", ""));

            temp = json.substring(json.indexOf("hair_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDoCabelo = temp;

            temp = json.substring(json.indexOf("skin_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDaPele = temp;

            temp = json.substring(json.indexOf("eye_color") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDosOlhos = temp;

            temp = json.substring(json.indexOf("birth_year") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.anoNascimento = temp;

            temp = json.substring(json.indexOf("gender") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            this.genero = temp;

            temp = json.substring(json.indexOf("homeworld") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.homeworld = temp;
        }

        public void imprimir() {
            System.out.println(toString());
        }

        public String toString() {
            DecimalFormat df = new DecimalFormat("#0.##");
            String resp = " ## " + nome + " ## " + altura + " ## ";
            resp += df.format(peso) + " ## " + corDoCabelo + " ## ";
            resp += corDaPele + " ## " + corDosOlhos + " ## ";
            resp += anoNascimento + " ## " + genero + " ## ";
            resp += homeworld + " ## ";
            return resp;
        }

        public void imprimirNome() {
            System.out.println(nome);
        }

    }// Fim da Classe Personagem

    public static boolean isFim(String s) {
        return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }

    public static String ISO88591toUTF8(String strISO) {
        try {
            byte[] isoBytes = strISO.getBytes("ISO-8859-1");
            return new String(isoBytes, "UTF-8");
        } catch (Exception e) {
            MyIO.println("ERRO: Ao converter!!");
        }
        return strISO;

    }

    public static void main(String[] args) {
        long tempoInicial = System.currentTimeMillis();
        Personagem Character = new Personagem();
        Arvore arvore = new Arvore();
        Arvore2 arvore2 = new Arvore2();
        int numEntrada = 0;
        String[] entrada = new String[1000];
        String[] entrada2 = new String[1000];
        String[] nomes = new String[1000];
        do {
            entrada[numEntrada] = MyIO.readLine();
        } while (isFim(entrada[numEntrada++]) == false);
        numEntrada--;
        try {
            for (int i = 0; i < numEntrada; i++) {
                Character.ler(entrada[i]);
                arvore.inserir(Character.clone());
            }
        } catch (Exception f) {
            MyIO.println("Exception Error Leitura Arvore1");
        }
        numEntrada = 0;
        
        //Inserindo na segunda arvore
        do {
            entrada2[numEntrada] = MyIO.readLine();
        } while (isFim(entrada2[numEntrada++]) == false);
        numEntrada--;
        try {
            for (int i = 0; i < numEntrada; i++) {
                Character.ler(entrada2[i]);
                arvore2.inserir2(Character.clone());
            }
        } catch (Exception z) {
            MyIO.println("Exception Error Leitura Arvore2");
        }
        numEntrada = 0;
        // Lendo os nomes
        do {
            nomes[numEntrada] = MyIO.readLine();
        } while (isFim(nomes[numEntrada++]) == false);
        numEntrada--;
        // Verificando se os nomes existem na arvore
        
        for (int i = 0; i < numEntrada; i++) {
             resp = false;
             MyIO.print(""+nomes[i]);
             arvore.pesquisarNome(nomes[i]);
             arvore2.pesquisarNome2(nomes[i]);
            if (resp == true) {
                MyIO.println(" SIM");
            } else {
                MyIO.println(" NÃO");
            }
        }
        long tempoFinal = System.currentTimeMillis();
        Arq.openWrite("matrícula_arvoreTrie.txt");
        Arq.println("637084\t"+"Numero de comparacoes: " + comp+ "\t Tempo de Execucao: " + (tempoFinal - tempoInicial));
        Arq.close();

        // Mostrar todos os elementos nas celulas
    }// Fim main
}
