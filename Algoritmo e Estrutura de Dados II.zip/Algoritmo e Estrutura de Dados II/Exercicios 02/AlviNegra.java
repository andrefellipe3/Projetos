import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DecimalFormat;

class AlviNegra{
    public static int comp = 0;


    static class No {
        public boolean cor;
        public Personagem personagem;
        public No esq, dir;

        public No (Personagem personagem){
            this(personagem, false, null, null);
        }
        public No (Personagem personagem, boolean cor){
            this(personagem, cor, null, null);
        }
        public No (Personagem personagem, boolean cor, No esq, No dir){
          this.cor = cor;
          this.personagem = personagem;
          this.esq = esq;
          this.dir = dir;
        }
      }//fim do No

    public static class ArvoreNegra {
        private No raiz;

        public ArvoreNegra() {
            raiz = null;
        }

        /**
	 * Metodo publico iterativo para pesquisar elemento.
	 * @param elemento Elemento que sera procurado.
	 * @return <code>true</code> se o elemento existir,
	 * <code>false</code> em caso contrario.
	 */
	public boolean pesquisar(String nome) {
        MyIO.print(nome);
        MyIO.print(" raiz");
		return pesquisar(nome, raiz);
	}

	/**
	 * Metodo privado recursivo para pesquisar elemento.
	 * @param elemento Elemento que sera procurado.
	 * @param i No em analise.
	 * @return <code>true</code> se o elemento existir,
	 * <code>false</code> em caso contrario.
	 */
	private boolean pesquisar(String nome, No i) {
      boolean resp;
      comp++;
		if (i == null) {
         resp = false;

      } else if (nome.equals(i.personagem.nome)) {
         resp = true;
         comp+= 1;

      } else if (nome.compareTo(i.personagem.nome) < 0) {
        comp+= 2;
        MyIO.print(" esq");
         resp = pesquisar(nome, i.esq);
      } else {
        MyIO.print(" dir");
         resp = pesquisar(nome, i.dir);
      }
      return resp;
	}


        /**
	 * Metodo publico iterativo para inserir elemento.
	 * @param elemento Elemento a ser inserido.
	 * @throws Exception Se o elemento existir.
	 */
	public void inserir(Personagem elemento) throws Exception {
        comp++;
   
        //Se a arvore estiver vazia
        if(raiz == null){
           raiz = new No(elemento, false);
  
        //Senao, se a arvore tiver um elemento 
        } else if (raiz.esq == null && raiz.dir == null){
            comp+= 1;
           if (raiz.personagem.nome.compareTo(elemento.nome) < 0){
            comp+= 2;
              raiz.esq = new No(elemento, true);
           } else {
              raiz.dir = new No(elemento, true);
           }
  
        //Senao, se a arvore tiver dois elementos (raiz e dir)
        } else if (raiz.esq == null){
            comp+= 3;
  
           if(raiz.personagem.nome.compareTo(elemento.nome) > 0){
            comp+= 4;
              raiz.esq = new No(elemento);
  
           } else if (raiz.dir.personagem.nome.compareTo(elemento.nome) > 0){
            comp+= 5;
              raiz.esq = new No(raiz.personagem);
              raiz.personagem = elemento;
  
           } else {
              raiz.esq = new No(raiz.personagem);
              raiz.personagem = raiz.dir.personagem;
              raiz.dir.personagem = elemento;
           }
  
           raiz.esq.cor = raiz.dir.cor = false;
           
        //Senao, se a arvore tiver dois elementos (raiz e esq)
        } else if (raiz.dir == null){
            comp+= 6;
           
           if(raiz.personagem.nome.compareTo(elemento.nome) < 0){
            comp+= 7;
              raiz.dir = new No(elemento);
           } else if (raiz.esq.personagem.nome.compareTo(elemento.nome) < 0){
            comp+= 8;
              raiz.dir = new No(raiz.personagem);
              raiz.personagem = elemento;
           } else {
              raiz.dir = new No(raiz.personagem);
              raiz.personagem = raiz.esq.personagem;
              raiz.esq.personagem = elemento;
           }
  
           raiz.esq.cor = raiz.dir.cor = false;
  
        //Senao, a arvore tem tres ou mais elementos
        } else {
             inserir(elemento, null, null, null, raiz);
        }
  
        raiz.cor = false;
     }

     private void balancear(No bisavo, No avo, No pai, No i){

        //Se o pai tambem e preto, reequilibrar a arvore, rotacionando o avo
        if(pai.cor == true){
  
           //4 tipos de reequilibrios e acoplamento
           if(pai.personagem.nome.compareTo(avo.personagem.nome) > 0){ // rotacao a esquerda ou direita-esquerda
              if(i.personagem.nome.compareTo(pai.personagem.nome) > 0){
                 avo = rotacaoEsq(avo);
              } else {
                 avo = rotacaoDirEsq(avo);
              }
  
           } else { // rotacao a direita ou esquerda-direita
              if(i.personagem.nome.compareTo(pai.personagem.nome) < 0){
                 avo = rotacaoDir(avo);
              } else {
                 avo = rotacaoEsqDir(avo);
              }
           }
  
           if (bisavo == null){
              raiz = avo;
           } else {
              if(avo.personagem.nome.compareTo(bisavo.personagem.nome) < 0){
                 bisavo.esq = avo;
              } else {
                 bisavo.dir = avo;
              }
           }
  
           //reestabelecer as cores apos a rotacao
           avo.cor = false;
           avo.esq.cor = avo.dir.cor = true;
        } 
     }
  
      /**
       * Metodo privado recursivo para inserir elemento.
       * @param elemento Elemento a ser inserido.
       * @param avo No em analise.
       * @param pai No em analise.
       * @param i No em analise.
       * @throws Exception Se o elemento existir.
       */
      private void inserir(Personagem elemento, No bisavo, No avo, No pai, No i) throws Exception {
          if (i == null) {
           if(elemento.nome.compareTo(pai.personagem.nome) < 0){
              i = pai.esq = new No(elemento, true);
           } else {
              i = pai.dir = new No(elemento, true);
           }
           if(pai.cor == true){
              balancear(bisavo, avo, pai, i);
           }
        } else {
          //Achou um 4-no: eh preciso fragmeta-lo e reequilibrar a arvore
           if(i.esq != null && i.dir != null && i.esq.cor == true && i.dir.cor == true){
              i.cor = true;
              i.esq.cor = i.dir.cor = false;
              if(i == raiz){
                 i.cor = false;
              }else if(pai.cor == true){
                 balancear(bisavo, avo, pai, i);
              }
           }
           if (elemento.nome.compareTo(i.personagem.nome) < 0) {
              inserir(elemento, avo, pai, i, i.esq);
           } else if (elemento.nome.compareTo(i.personagem.nome) > 0) {
              inserir(elemento, avo, pai, i, i.dir);
           } else {
              throw new Exception("Erro inserir (elemento repetido)!");
           }
        }
      }
  
     private No rotacaoDir(No no) {
        No noEsq = no.esq;
        No noEsqDir = noEsq.dir;
  
        noEsq.dir = no;
        no.esq = noEsqDir;
  
        return noEsq;
     }
  
     private No rotacaoEsq(No no) {
        No noDir = no.dir;
        No noDirEsq = noDir.esq;
  
        noDir.esq = no;
        no.dir = noDirEsq;
        return noDir;
     }
  
     private No rotacaoDirEsq(No no) {
        no.dir = rotacaoDir(no.dir);
        return rotacaoEsq(no);
     }
  
     private No rotacaoEsqDir(No no) {
        no.esq = rotacaoEsq(no.esq);
        return rotacaoDir(no);
     }




    }


    static class Personagem {
        private String nome;
        private int altura;
        private double peso;
        private String corDoCabelo;
        private String corDaPele;
        private String corDosOlhos;
        private String anoNascimento;
        private String genero;
        private String homeworld;

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public int getAltura() {
            return altura;
        }

        public void setAltura(int altura) {
            this.altura = altura;
        }

        public double getPeso() {
            return peso;
        }

        public void setPeso(double peso) {
            this.peso = peso;
        }

        public String getCorDoCabelo() {
            return corDoCabelo;
        }

        public void setCorDoCabelo(String corDoCabelo) {
            this.corDoCabelo = corDoCabelo;
        }

        public String getCorDaPele() {
            return corDaPele;
        }

        public void setCorDaPele(String corDaPele) {
            this.corDaPele = corDaPele;
        }

        public String getCorDosOlhos() {
            return corDosOlhos;
        }

        public void setCorDosOlhos(String corDosOlhos) {
            this.corDosOlhos = corDosOlhos;
        }

        public String getAnoNascimento() {
            return anoNascimento;
        }

        public void setAnoNascimento(String anoNascimento) {
            this.anoNascimento = anoNascimento;
        }

        public String getGenero() {
            return genero;
        }

        public void setGenero(String genero) {
            this.genero = genero;
        }

        public String getHomeworld() {
            return homeworld;
        }

        public void setHomeworld(String homeworld) {
            this.homeworld = homeworld;
        }

        public Personagem clone() {
            Personagem novo = new Personagem();
            novo.nome = this.nome;
            novo.altura = this.altura;
            novo.peso = this.peso;
            novo.corDoCabelo = this.corDoCabelo;
            novo.corDaPele = this.corDaPele;
            novo.corDosOlhos = this.corDosOlhos;
            novo.anoNascimento = this.anoNascimento;
            novo.genero = this.genero;
            novo.homeworld = this.homeworld;
            return novo;
        }

        public void ler(String nomeArquivo) throws Exception {
            FileReader file = new FileReader(nomeArquivo);
            BufferedReader buffer = new BufferedReader(file);
            String json = "";
            String line = buffer.readLine();
            while (line != null) {
                json += line;
                line = buffer.readLine();
            }

            buffer.close();
            file.close();

            String temp;
            temp = json.substring(json.indexOf("name") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            this.nome = temp;

            temp = json.substring(json.indexOf("height") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.altura = 0;
            else
                this.altura = Integer.parseInt(temp);

            temp = json.substring(json.indexOf("mass") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.peso = 0;
            else
                this.peso = Double.parseDouble(temp.replace(",", ""));

            temp = json.substring(json.indexOf("hair_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDoCabelo = temp;

            temp = json.substring(json.indexOf("skin_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDaPele = temp;

            temp = json.substring(json.indexOf("eye_color") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDosOlhos = temp;

            temp = json.substring(json.indexOf("birth_year") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.anoNascimento = temp;

            temp = json.substring(json.indexOf("gender") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            this.genero = temp;

            temp = json.substring(json.indexOf("homeworld") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.homeworld = temp;
        }

        public void imprimir() {
            System.out.println(toString());
        }

        public String toString() {
            DecimalFormat df = new DecimalFormat("#0.##");
            String resp = " ## " + nome + " ## " + altura + " ## ";
            resp += df.format(peso) + " ## " + corDoCabelo + " ## ";
            resp += corDaPele + " ## " + corDosOlhos + " ## ";
            resp += anoNascimento + " ## " + genero + " ## ";
            resp += homeworld + " ## ";
            return resp;
        }

        public void imprimirNome() {
            System.out.println(nome);
        }

    }// Fim da Classe Personagem

    public static boolean isFim(String s) {
        return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }

    public static String ISO88591toUTF8(String strISO) {
        try {
            byte[] isoBytes = strISO.getBytes("ISO-8859-1");
            return new String(isoBytes, "UTF-8");
        } catch (Exception e) {
            MyIO.println("ERRO: Ao converter!!");
        }
        return strISO;

    }

    public static void main(String[] args) {
        long tempoInicial = System.currentTimeMillis();
        boolean resp;
        Personagem Character = new Personagem();
        ArvoreNegra alvinegra = new ArvoreNegra();
        int numEntrada = 0;
        String[] entrada = new String[1000];
        String[] nomes = new String[1000];
        do {
            entrada[numEntrada] = MyIO.readLine();
        } while (isFim(entrada[numEntrada++]) == false);
        numEntrada--;
        try {
            for (int i = 0; i < numEntrada; i++) {
                Character.ler(entrada[i]);
                alvinegra.inserir(Character.clone());
            }
        } catch (Exception f) {
            MyIO.println("Exception Error Leitura");
        }
        numEntrada = 0;
        // Lendo os nomes
        do {
            nomes[numEntrada] = MyIO.readLine();
        } while (isFim(nomes[numEntrada++]) == false);
        numEntrada--;
        // Verificando se os nomes existem na arvore
        
        for (int i = 0; i < numEntrada; i++) {
            resp = alvinegra.pesquisar(nomes[i]);
            if (resp == true) {
                MyIO.println(" SIM");
            } else {
                MyIO.println(" NÃO");
            }
        }
        long tempoFinal = System.currentTimeMillis();
        Arq.openWrite("matrícula_avl.txt");
        Arq.println("637084\t"+"Numero de comparacoes: " + comp+ "\t Tempo de Execucao: " + (tempoFinal - tempoInicial));
        Arq.close();

        // Mostrar todos os elementos nas celulas
    }// Fim main
}
