
class MatrizDinamica {

   static class Celula {
      Celula esquerda, direita, superior, inferior;
      public int elemento;

      public void Celula() {
         elemento = 0;
         esquerda = direita = superior = inferior = null;
      }
   }

   static class Matriz {
      Celula primeiro;
      int linhas, colunas;

      public void Matriz() {
         primeiro = new Celula();
         colunas = linhas = 3;
      }

      public void Matriz(int linhas, int colunas) {
         primeiro = new Celula();
         this.linhas = linhas;
         this.colunas = colunas;
         Criar();
      }
     
      public void Pos(int l, int c, int elemento) {
         Celula resp = primeiro;
         if (l < 0 || l >= linhas || c < 0 || c >= colunas)
         {
            MyIO.println("ERROR");
            MyIO.println("L:"+l);
            MyIO.println("LINHAS:"+linhas);
            MyIO.println("C:"+c);
            MyIO.println("COLUNAS:"+colunas);
         }
         else {
            int i = 0;
            for (i = 0; i < l; i++, resp = resp.inferior)
               ;
            for (i = 0; i < c; i++, resp = resp.direita)
               ;
            resp.elemento = elemento;
         }
      }
      public Celula pegarPos(int l, int c) {
         Celula resp = primeiro;
      if (l < 0 || l >= linhas || c < 0 || c >= colunas)
            resp = null;
         else {
            int i = 0;
            for (i = 0; i < c; i++, resp = resp.direita)
               ;
            for (i = 0; i < l; i++, resp = resp.inferior)
               ;
         }
         return resp;
      }

      // metodo que cria a matriz e liga os ponteiros
      public void Criar() {
         // variaveis auxiliares para percorrer a matriz
         int l, c;
         Celula i, j, tmp;
         i = pegarPos(0, 0);
         j = primeiro;
         for (c = 0; c < colunas; j = j.direita, c++) {
            tmp = new Celula();
            j.direita = tmp;
            tmp = null;
         }
         j = primeiro;
         for (c = 0; c < colunas; j = j.direita, c++) {
            tmp = new Celula();
            j.inferior = tmp;
            tmp = null;
            i = j.inferior;
            for (l = 1; l < linhas; i = i.inferior, l++) {
               tmp = new Celula();
               i.inferior = tmp;
               tmp = null;
            }
         }
         // Conectando todas as direcoes
         for (l = 0; l < linhas; l++) {
            for (c = 0; c < colunas; c++) {
               i = pegarPos(l, c);
               i.esquerda = pegarPos(l, c - 1);
               i.direita = pegarPos(l, c + 1);
               i.superior = pegarPos(l - 1, c);
               i.inferior = pegarPos(l + 1, c);
            }
         }
      }

   } //fim classe
   public static boolean isFim(String s) {
      return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
   }

   static void MostrarDiagonalPrincipal(Matriz x) {
      Celula i = x.primeiro;
      
      if (x.linhas == x.colunas && x.linhas > 0)
         for (int y = 0; y < x.linhas; y++) {
            MyIO.print("" + i.elemento + " ");
            if (i.direita != null)
               i = i.direita.inferior;
         }

      else
         MyIO.println("Erro: Matriz nao quadrada!");
         MyIO.print("\n");
   }

   static void MostrarDiagonalSecundaria(Matriz x) {
      Celula i = x.primeiro;
      for(; i.direita != null; i = i.direita);

      if (x.linhas == x.colunas && x.linhas > 0)
         for (int k = 0; k < x.linhas; k++) {
            MyIO.print("" + i.elemento + " ");
            if (i.esquerda != null)
               i = i.esquerda.inferior;
         }

      else
         MyIO.println("Erro: Matriz nao quadrada!");
         MyIO.print("\n");
   }

   static boolean matrizIguais(Matriz x, Matriz y) {
      return (x.linhas == y.linhas && x.colunas == y.colunas);
   }  

   static Matriz soma(Matriz x, Matriz y) {
      Matriz resp = new Matriz();
      resp.Matriz(x.linhas, x.colunas);

      if (matrizIguais(x, y) == false)
   {
        resp = null;
   }
      else {
         Celula i = x.primeiro;
         Celula j = y.primeiro;
         Celula r = resp.primeiro;
         int l, c;

         for (l = 0; l < x.linhas; l++) {
            for (c = 0; c < x.colunas; c++) {
               r.elemento = i.elemento + j.elemento;
               MyIO.print(""+r.elemento+" ");
               i = i.direita;
               j = j.direita;
               r = r.direita;
            }
            i = x.primeiro;
            j = y.primeiro;
            r = resp.primeiro;
            MyIO.print("\n");
            for (int k = 0; k <= l; k++) {
               i = i.inferior;
               j = j.inferior;
               r = r.inferior;
            }
         }

      }

      return resp;
   }

   static Matriz multiplicar(Matriz x, Matriz y) {
      Matriz resp = new Matriz();
      resp.Matriz(x.linhas, x.colunas);

      if (matrizIguais(x, y) == false)
         resp = null;

      else {
         Celula i = x.primeiro;
         Celula j = y.primeiro;
         Celula z = x.primeiro;
         Celula v = y.primeiro;
         z = z.direita;
         v = v.inferior;
         Celula r = resp.primeiro;
         int l, c;

         for (l = 0; l < x.linhas; l++) {
            for (c = 0; c < x.colunas; c++) {
               r.elemento = i.elemento * j.elemento + z.elemento * v.elemento;
               MyIO.print(""+r.elemento+" ");
               if(j.direita != null && v.direita != null)
               {
               j = j.direita;
               v = v.direita;
               }
               r = r.direita;
            }
            i = x.primeiro;
            j = y.primeiro;
            v = y.primeiro;
            v = v.inferior;
            r = resp.primeiro;
            MyIO.print("\n");
            i = i.inferior;
            z = z.inferior;
            r = r.inferior;
         }

      }

      return resp;
   }

   static void Mostrar(Matriz x) {
      Celula i = x.primeiro;
      int l, c;
      for (l = 0; l < x.linhas; l++) {
         for (c = 0; c < x.colunas; c++) {
            if (i.direita != null)
            {
            MyIO.print(""+i.elemento+"");
            }
            i = i.direita;
         }
         i = x.primeiro;
         for (int k = 0; k <= l; k++)
            i = i.inferior;
         MyIO.print("\n");
      }
   }
   public static void main(String[] args) {
      int entrada = 0;
      int y = 0;
      int n = 0,m = 0, i = 0, j = 0,count = 0;
      count = MyIO.readInt();
      for(y = 0; y < count; y++) {
         n = MyIO.readInt();
         m = MyIO.readInt();
         Matriz m1 = new Matriz();
         m1.Matriz(n,m);
         // Pegando Matriz 1
         for ( j = 0; j < n; j++) {
            for ( i = 0; i < m; i++)
            {
            entrada = MyIO.readInt();
               m1.Pos(j,i,entrada);
            }
         }
         n = MyIO.readInt();
         m = MyIO.readInt();
         Matriz m2 = new Matriz();
         m2.Matriz(n,m);
         // Pegando Matriz 2
         for ( j = 0; j < n; j++) {
            for ( i = 0; i < m; i++)
            {
            entrada = MyIO.readInt();
               m2.Pos(j,i,entrada);
            }
         }
         MostrarDiagonalPrincipal(m1);
         MostrarDiagonalSecundaria(m1);
         soma(m1,m2);
         multiplicar(m1,m2);
         }//fim while 
      } 
}