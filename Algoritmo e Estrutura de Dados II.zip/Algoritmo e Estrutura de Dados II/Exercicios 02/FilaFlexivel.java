import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DecimalFormat;

class FilaFlexivel {

    static class Celula {
        public Personagem elemento; // Elemento inserido na celula.
        public Celula prox; // Aponta a celula prox.

        /**
         * Construtor da classe.
         */
        public Celula() {

        }

        
        //Construtor da classe.
        public Celula(Personagem x) {
            this.elemento = x;
            this.prox = null;
        }
    }
    

    static class Fila {
        private Celula primeiro;
        private Celula ultimo;
        public int n = 1;
        float mediaAltura;

        public Fila() {
            primeiro = new Celula();
            ultimo = primeiro;
        }

        
    //Insere um elemento na ultima posicao da lista.
    public void inserir(Personagem x) {  
        if (n >= 6)
        {
        try {
        remover();
       } catch (Exception d) 
       {
        MyIO.println("Erro ao remover");
       }
       }
        ultimo.prox = new Celula(x);
        ultimo = ultimo.prox;
        mediaAltura(); 
        int resp = Math.round(mediaAltura);
       MyIO.println(resp);
       n++;
    }


	/**
	 * Remove elemento da fila (politica FIFO).
	 * @return Elemento removido.
	 * @trhows Exception Se a fila nao tiver elementos.
	 */
	public Personagem remover() throws Exception {
		if (primeiro == ultimo) {
			throw new Exception("Erro ao remover!");
		}

      Celula tmp = primeiro;
		primeiro = primeiro.prox;
		Personagem resp = primeiro.elemento;
      tmp.prox = null;
      tmp = null;
      n--;
		return resp;
    }
    
    /**
         * Mostra os elementos da lista separados por espacos.
         */
        public void mostrar() {
            int count = 0;
            for (Celula i = primeiro.prox; i != null; i = i.prox) {
                System.out.print("[" + count + "] " + i.elemento + "\n");
                count++;
            }

        }


void mediaAltura ()
{
mediaAltura = 0;
for(Celula i = primeiro.prox; i != null; i = i.prox)
{
   mediaAltura += i.elemento.altura;
}
//Fazendo a media
mediaAltura = (mediaAltura)/(n);
}
 
        /**
         * Calcula e retorna o tamanho, em numero de elementos, da lista.
         * 
         * @return resp int tamanho
         */
        public int tamanho() {
            int tamanho = 0;
            for (Celula i = primeiro; i != ultimo; i = i.prox, tamanho++)
                ;
            return tamanho;
        }
    }


    static class Personagem {
        private String nome;
        private int altura;
        private double peso;
        private String corDoCabelo;
        private String corDaPele;
        private String corDosOlhos;
        private String anoNascimento;
        private String genero;
        private String homeworld;

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public int getAltura() {
            return altura;
        }

        public void setAltura(int altura) {
            this.altura = altura;
        }

        public double getPeso() {
            return peso;
        }

        public void setPeso(double peso) {
            this.peso = peso;
        }

        public String getCorDoCabelo() {
            return corDoCabelo;
        }

        public void setCorDoCabelo(String corDoCabelo) {
            this.corDoCabelo = corDoCabelo;
        }

        public String getCorDaPele() {
            return corDaPele;
        }

        public void setCorDaPele(String corDaPele) {
            this.corDaPele = corDaPele;
        }

        public String getCorDosOlhos() {
            return corDosOlhos;
        }

        public void setCorDosOlhos(String corDosOlhos) {
            this.corDosOlhos = corDosOlhos;
        }

        public String getAnoNascimento() {
            return anoNascimento;
        }

        public void setAnoNascimento(String anoNascimento) {
            this.anoNascimento = anoNascimento;
        }

        public String getGenero() {
            return genero;
        }

        public void setGenero(String genero) {
            this.genero = genero;
        }

        public String getHomeworld() {
            return homeworld;
        }

        public void setHomeworld(String homeworld) {
            this.homeworld = homeworld;
        }

        public Personagem clone() {
            Personagem novo = new Personagem();
            novo.nome = this.nome;
            novo.altura = this.altura;
            novo.peso = this.peso;
            novo.corDoCabelo = this.corDoCabelo;
            novo.corDaPele = this.corDaPele;
            novo.corDosOlhos = this.corDosOlhos;
            novo.anoNascimento = this.anoNascimento;
            novo.genero = this.genero;
            novo.homeworld = this.homeworld;
            return novo;
        }

        public void ler(String nomeArquivo) throws Exception {
            FileReader file = new FileReader(nomeArquivo);
            BufferedReader buffer = new BufferedReader(file);
            String json = "";
            String line = buffer.readLine();
            while (line != null) {
                json += line;
                line = buffer.readLine();
            }

            buffer.close();
            file.close();

            String temp;
            temp = json.substring(json.indexOf("name") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            this.nome = temp;

            temp = json.substring(json.indexOf("height") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.altura = 0;
            else
                this.altura = Integer.parseInt(temp);

            temp = json.substring(json.indexOf("mass") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.peso = 0;
            else
                this.peso = Double.parseDouble(temp.replace(",", ""));

            temp = json.substring(json.indexOf("hair_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDoCabelo = temp;

            temp = json.substring(json.indexOf("skin_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDaPele = temp;

            temp = json.substring(json.indexOf("eye_color") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDosOlhos = temp;

            temp = json.substring(json.indexOf("birth_year") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.anoNascimento = temp;

            temp = json.substring(json.indexOf("gender") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            this.genero = temp;

            temp = json.substring(json.indexOf("homeworld") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.homeworld = temp;
        }

        public void imprimir() {
            System.out.println(toString());
        }

        public String toString() {
            DecimalFormat df = new DecimalFormat("#0.##");
            String resp = " ## " + nome + " ## " + altura + " ## ";
            resp += df.format(peso) + " ## " + corDoCabelo + " ## ";
            resp += corDaPele + " ## " + corDosOlhos + " ## ";
            resp += anoNascimento + " ## " + genero + " ## ";
            resp += homeworld + " ## ";
            return resp;
        }

        public void imprimirNome() {
            System.out.println(nome);
        }

    }// Fim da Classe Personagem

    public static boolean isFim(String s) {
        return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }

    public static String ISO88591toUTF8(String strISO) {
        try {
            byte[] isoBytes = strISO.getBytes("ISO-8859-1");
            return new String(isoBytes, "UTF-8");
        } catch (Exception e) {
            MyIO.println("ERRO: Ao converter!!");
        }
        return strISO;

    }

    public static void main(String[] args) {
        MyIO.setCharset("UTF-8");
        Personagem Character = new Personagem();
        String count;
        Fila fila = new Fila();
        int numEntrada = 0, y = 0;
        String[] entrada = new String[1000];
        do {
            entrada[numEntrada] = MyIO.readLine();
        } while (isFim(entrada[numEntrada++]) == false);
        numEntrada--;
        try {
            for (int i = 0; i < numEntrada; i++) {
                Character.ler(entrada[i]);
                fila.inserir(Character.clone());

            }
        } catch (Exception f) {
            MyIO.println("Exception Error Leitura");
        }
        count = MyIO.readLine();
        y = Integer.parseInt(count);

        // Limpar os vetores de string
        for (int i = 0; i < numEntrada; i++) {
            entrada[i] = "";
        }

        // Fazendo a veficacao e alteracao
        for (int i = 0; i < y; i++) {
            entrada[i] = MyIO.readLine();

            // Inserir no Inicio
            if (entrada[i].charAt(0) == 'I') {
                try {
                    entrada[i] = entrada[i].replace("I ", "");
                    Character.ler(entrada[i]);
                    fila.inserir(Character.clone());
                } catch (Exception a) {
                    MyIO.println("Exception Error InserirInicio");
                }
            }

            // Remover no inicio
            if (entrada[i].equals("R")) {
                try {
                    MyIO.println("(R) " + fila.remover().nome);
                } catch (Exception d) {
                    MyIO.println("Exception Error RemoverInicio");
                }
            }
        } // Fim teste e alteracao
        //Mostrar todos os elementos nas celulas
        fila.mostrar();
    }// Fim main
}
