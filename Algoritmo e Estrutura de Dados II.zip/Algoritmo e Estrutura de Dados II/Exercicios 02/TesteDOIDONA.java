class Doidona
{
 int[] T1;
 int[] T2;
 int[] T3;
 int reserva0= 0;
 int reserva1 = 1;
 int reserva2 = 2;
 int reservaT3;
 ArvoreAlvinegra arvnegra;
 Lista lista[tamanho];
 AVL arvoreAVL;

 public void inserir(int elemento)
{
      int i = hashT1(elemento);
      if(elemento == null) 
{
t1[i] = elemento;
} 
//Se a posicao tiver ocupada por um valor
else if(T1[i] != null)
{
//Se o valor for igual a primeira reserva da T1 eu encaminho pra tabela T2
if ( i == reserva0)
{
 i = hashT2(elemento);
//Se a posicao indicada na Hash2 estiver vazia eu insiro o elemento
if (T2[i] == null)
{
T2[i] = elemento;
}
//Se ja existir elemento em tal posicao, eu uso a rehash pra tentar encaixar na proxima posição
else if (T2[i] != null)
{
i = rehashT2(elemento);
//Se existir espaço pro elemento ser inserido na T2, eu irei inserir na T2
if(T2[i] == null)
{
T2[I] = elemento;
}
//Se a posicao da rehash estiver ocupada tbm,irei inserir o elemento na arvore AVL
else if (t2[i] != null)
{
arvoreAVL.inserir(elemento);
}
}
}//fim da reserva0

//Se i for igual a reserva1
if (i == reserva1)
{
i = hashT3(elemento);    
//Se estiver espaço pra inserir
if (T3[i] == null)
{
T3[i] = elemento;  
}
//se houver elemento na tabelaT3 normal, eu tento inserir na reserva
else if (T3[i] != null)
{
 i = rehashT3(elemento);
 //Verificando se existe elemento na reserva da T3, se não tiver insere, se não, não insere.
if (T3[i] == null)
{
T3[i+reservaT3];
}    
}
}//fim da Reserva1
//Se o valor do mod(i) for igual a reserva2
if (i == reserva2)
{
i = hashT4(elemento);
//Se houver espaço na tabela hash de lista, eu insiro
if(T4[i] == null)  
{
T4[i] = elemento;   
} 
//Se eu tentar inserir na posicao 3 da T4,e ja tiver elemento, eu insiro na arvorealvinegra
else if (T4[3] != null)
{
arvnegra.inserir(elemento);   
}
}//fim da reserva2
}//fim do else if T1
}//fim da classe