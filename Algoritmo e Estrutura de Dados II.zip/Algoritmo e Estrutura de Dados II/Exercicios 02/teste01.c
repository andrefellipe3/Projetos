#include <stdio.h>
int main ( )
{
int *p;
int v[] = {10,7,2,6,3};
p = v;
printf("%d",p);    
}