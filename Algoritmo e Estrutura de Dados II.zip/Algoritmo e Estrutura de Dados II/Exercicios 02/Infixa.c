#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAMANHO 1000

int prec(char operador);
void paraPosfixa(const char *exp, char *saida);

int main(void)
{

  int n;

  char infixa[TAMANHO], posfixa[TAMANHO];
  //Numero de entradas
  scanf("%d\n", &n);

  while (n-- > 0)
  {
    fgets(infixa, TAMANHO, stdin);
    paraPosfixa(infixa, posfixa);
    printf("%s\n", posfixa);
  }

  return 0;
}

void paraPosfixa(const char *exp, char *saida)
{
  char p[TAMANHO];
  int i, o = 0, t = -1;
  char c;

  for (i = 0; exp[i] != '\n' && exp[i] != '\0'; i++)
  {

    c = exp[i];

    if (c == ' ')
      continue;

    if (c == '(')
    {

      p[++t] = c;
    }

    else if (c == ')')
    {

      while (t > -1 && p[t] != '(')
      {

        saida[o++] = p[t--];
      }

      t--;
    }

    else if ((c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z'))
    {

      saida[o++] = c;
    }

    else
    {

      while (t > -1 && p[t] != '(' && prec(p[t]) >= prec(c))
      {

        saida[o++] = p[t--];
      }

      p[++t] = c;
    }
  }

  while (t > -1)
    saida[o++] = p[t--];

  saida[o++] = '\0';
}

int prec(char operador)
{

  switch (operador)
  {
  case '^':

    return 3;
  case '*':

    return 2;

  case '/':

    return 2;

  case '+':

    return 1;

  case '-':

    return 1;

  default:

    return 0;
  }
}