#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int verifica(int pos, char aux[], char valor){
    int i;
    for(i = 0; i < pos; i ++){
        if(aux[i] == valor)
            return 0;
    }
    return 1;
}

void backtracking(int i, char vetor[], char aux[], int tam){
    int j;
    for(j = 0; j < tam; j ++){
        if(verifica(i, aux, vetor[j]) == 1){
            aux[i] = vetor[j];
            backtracking(i + 1, vetor, aux, tam);
        }
    }
    if(i + 1 == tam){
        aux[tam] = '\0'; 
        puts(aux);
    }
}

void selection_sort(char vetor[], int tam){
    int i, j, min;
    char aux;
    for(i = 0; i < tam - 1; i ++){
        min = i;
        for(j = i + 1; j < tam; j ++){
            if(vetor[j] < vetor[min]) min = j;
        }
        if(min != i){
            aux = vetor[i];
            vetor[i] = vetor[min];
            vetor[min] = aux;
        }
    }
}

int main()
{
    int tam, n;
    char vetor[20], aux[20];
    scanf("%d", &n);
    getchar();
    do{
        fgets(vetor);
        tam = strlen(vetor);
        selection_sort(vetor, tam);
        backtracking(0, vetor, aux, tam);
        printf("\n");
        n --;
    }while(n > 0);
}