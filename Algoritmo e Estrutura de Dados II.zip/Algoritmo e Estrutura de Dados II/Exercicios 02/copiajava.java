public class copiajava {
    
    public static void main (String[] args)
    {
    int[] carta1 = new int[1000];
    int[] carta2 = new int[1000];
    int[] carta3  = new int[1000];
    int[] resultado  = new int[1000];
    int resposta = 0;
    int soma = 0,x = 0;
    int z = 1;
    while ( z != 0){
    if (z == 0){
    break;
    }    
    z = 0;
    z = MyIO.readInt();
    for(int i = 0; i < z; i++){
    carta1[i] = MyIO.readInt();
    carta2[i] = MyIO.readInt();
    carta3[i] = MyIO.readInt();
    }   
    for (int y = 0; y < z; y++){
    soma = carta1[y] + carta2[y] + carta3[y];
    
    if ( soma % 3 == 0){
    resposta = 1;  
    }
    else{
    y = z-1;    
    }
    }
    resultado[x] = resposta;
    x++;
    resposta = 0;
    }
    for ( int i = 0; i < x-1; i++){
        MyIO.println("" + resultado[i]);
    }
    }   
    }  
    