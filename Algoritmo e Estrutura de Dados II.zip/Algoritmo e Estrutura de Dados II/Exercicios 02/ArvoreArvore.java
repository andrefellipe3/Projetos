import java.io.BufferedReader;
import java.io.FileReader;
import java.text.DecimalFormat;

class ArvoreArvore {
    public static int mov,comp,i = 0;
    public static boolean valor = false;

    static class No {
        public int elemento;
        public No esq, dir;
        public No2 outro;

        /**
         * Construtor da classe.
         * 
         * @param altura Conteudo do no.
         * @param esq      No da esquerda.
         * @param dir      No da direita.
         */
        public No(int elemento, No esq, No dir,No2 outro) {
            this.elemento = elemento;
            this.esq = esq;
            this.dir = dir;
            this.outro = outro;
        }

        No(int elemento) {
            this.elemento = elemento;
            this.esq = this.dir = null;
            this.outro = null;
         }

        public No() {

        }

    }// Fim No

    static class No2 {
        public Personagem personagem;
        public No2 esq, dir;

        /**
         * Construtor da classe.
         * 
         * @param elemento Conteudo do no.
         * @param esq      No da esquerda.
         * @param dir      No da direita.
         */
        public No2(Personagem personagem, No2 esq, No2 dir) {
            this.personagem = personagem;
            this.esq = esq;
            this.dir = dir;
        }

        No2(Personagem elemento) {
            this.personagem = elemento;
            this.esq = this.dir = null;
         }

        public No2() {

        }
    }


    public static class Arvore1 {
        public No raiz;

        public Arvore1() {
            raiz = null;
        }
        //Insere Elementos inteiros
        public void inserir(int elemento) throws Exception {
            raiz = inserir(raiz, elemento);
        }
        //Insere Elementos inteiros
        private No inserir(No no, int elemento) throws Exception {
            comp++;
            if (no == null) {
                no = new No(elemento);
            }

            else if (elemento < no.elemento) {
                no.esq = inserir(no.esq, elemento);
                comp += 1;
            } 
            else if (elemento > no.elemento) {
                no.dir = inserir(no.dir, elemento);
                comp += 2;
            } 
            else {
                throw new Exception("Erro ao inserir");
            }
            return no;
        }

        public boolean inserirElemento(int mod,Personagem personagem) {
            return inserirElemento(raiz,mod,personagem);
        }
    
        private boolean inserirElemento(No no,int mod,Personagem personagem) {
            boolean resp;
            if (no == null) {
                resp = false;
            } else if (no.elemento == mod) {
               resp = true;
               inserir3(no.outro,personagem); //Inserindo personagens na arvore

            } else if (no.elemento < mod) {
                resp = inserirElemento(no.esq,mod,personagem);

            } else {
                resp = inserirElemento(no.dir, mod,personagem);
            }
            return resp;
        }
        //Inserção dos Personagens na Arvore
        //public void inserir2(No no,Personagem personagem)  {
          //  inserir3(no.outro,personagem); //Inserindo personagens na arvore
        //}
        
        //Inserção dos Personagens na Arvore
        private No2 inserir3(No2 no, Personagem personagem)  {
            comp++;
            if (no == null) {
                no = new No2(personagem);
            }

            else if (personagem.nome.compareTo(no.personagem.nome) < 0) {
                no.esq = inserir3(no.esq, personagem);
                comp += 1;
            } 
            else if (personagem.nome.compareTo(no.personagem.nome) > 0) {
                no.dir = inserir3(no.dir, personagem);
                comp += 2;
            } 
            else {
                MyIO.println("Erro ao inserir");
            }
            return no;
        }

        public void pesquisarPersonagem(No2 no, String x) 
        {
          if (no == null) { 
           ;
  
        } else if (x.equals(no.personagem.nome)) { 
           valor = true; 
  
        } else if (x.compareTo(no.personagem.nome) < 0) { 
            MyIO.println(" ESQ");
           pesquisarPersonagem(no.esq, x); 
  
        } else { 
            MyIO.println(" DIR");
            pesquisarPersonagem(no.dir, x); 
        }
      }

        public void pesquisarInt(String x)
        { 
        pesquisarInt(raiz,x);
        }
        
        public void pesquisarInt(No no, String x) {
          if (no != null)
          {
          pesquisarPersonagem(no.outro,x);
          if (!valor)
          {
          MyIO.print(" esq");
          pesquisarInt(no.esq,x);
          }
          if(!valor)
        {
          MyIO.print(" dir");
          pesquisarInt(no.dir,x);
        }
          }
          }

    }//Fim Arvore1
    

    static class Personagem {
        private String nome;
        private int altura;
        private double peso;
        private String corDoCabelo;
        private String corDaPele;
        private String corDosOlhos;
        private String anoNascimento;
        private String genero;
        private String homeworld;

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public int getAltura() {
            return altura;
        }

        public void setAltura(int altura) {
            this.altura = altura;
        }

        public double getPeso() {
            return peso;
        }

        public void setPeso(double peso) {
            this.peso = peso;
        }

        public String getCorDoCabelo() {
            return corDoCabelo;
        }

        public void setCorDoCabelo(String corDoCabelo) {
            this.corDoCabelo = corDoCabelo;
        }

        public String getCorDaPele() {
            return corDaPele;
        }

        public void setCorDaPele(String corDaPele) {
            this.corDaPele = corDaPele;
        }

        public String getCorDosOlhos() {
            return corDosOlhos;
        }

        public void setCorDosOlhos(String corDosOlhos) {
            this.corDosOlhos = corDosOlhos;
        }

        public String getAnoNascimento() {
            return anoNascimento;
        }

        public void setAnoNascimento(String anoNascimento) {
            this.anoNascimento = anoNascimento;
        }

        public String getGenero() {
            return genero;
        }

        public void setGenero(String genero) {
            this.genero = genero;
        }

        public String getHomeworld() {
            return homeworld;
        }

        public void setHomeworld(String homeworld) {
            this.homeworld = homeworld;
        }

        public Personagem clone() {
            Personagem novo = new Personagem();
            novo.nome = this.nome;
            novo.altura = this.altura;
            novo.peso = this.peso;
            novo.corDoCabelo = this.corDoCabelo;
            novo.corDaPele = this.corDaPele;
            novo.corDosOlhos = this.corDosOlhos;
            novo.anoNascimento = this.anoNascimento;
            novo.genero = this.genero;
            novo.homeworld = this.homeworld;
            return novo;
        }

        public void ler(String nomeArquivo) throws Exception {
            FileReader file = new FileReader(nomeArquivo);
            BufferedReader buffer = new BufferedReader(file);
            String json = "";
            String line = buffer.readLine();
            while (line != null) {
                json += line;
                line = buffer.readLine();
            }

            buffer.close();
            file.close();

            String temp;
            temp = json.substring(json.indexOf("name") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            this.nome = temp;

            temp = json.substring(json.indexOf("height") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.altura = 0;
            else
                this.altura = Integer.parseInt(temp);

            temp = json.substring(json.indexOf("mass") + 8);
            temp = temp.substring(0, temp.indexOf("',"));
            if (temp.equals("unknown"))
                this.peso = 0;
            else
                this.peso = Double.parseDouble(temp.replace(",", ""));

            temp = json.substring(json.indexOf("hair_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDoCabelo = temp;

            temp = json.substring(json.indexOf("skin_color") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDaPele = temp;

            temp = json.substring(json.indexOf("eye_color") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.corDosOlhos = temp;

            temp = json.substring(json.indexOf("birth_year") + 14);
            temp = temp.substring(0, temp.indexOf("',"));
            this.anoNascimento = temp;

            temp = json.substring(json.indexOf("gender") + 10);
            temp = temp.substring(0, temp.indexOf("',"));
            this.genero = temp;

            temp = json.substring(json.indexOf("homeworld") + 13);
            temp = temp.substring(0, temp.indexOf("',"));
            this.homeworld = temp;
        }

        public void imprimir() {
            System.out.println(toString());
        }

        public String toString() {
            DecimalFormat df = new DecimalFormat("#0.##");
            String resp = " ## " + nome + " ## " + altura + " ## ";
            resp += df.format(peso) + " ## " + corDoCabelo + " ## ";
            resp += corDaPele + " ## " + corDosOlhos + " ## ";
            resp += anoNascimento + " ## " + genero + " ## ";
            resp += homeworld + " ## ";
            return resp;
        }

        public void imprimirNome() {
            System.out.println(nome);
        }

    }// Fim da Classe Personagem

    public static boolean isFim(String s) {
        return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
    }

    public static String ISO88591toUTF8(String strISO) {
        try {
            byte[] isoBytes = strISO.getBytes("ISO-8859-1");
            return new String(isoBytes, "UTF-8");
        } catch (Exception e) {
            MyIO.println("ERRO: Ao converter!!");
        }
        return strISO;

    }

    public static void main(String[] args) {
        long tempoInicial = System.currentTimeMillis();
        int [] array = {7,3,11,1,5,9,12,0,2,4,6,8,10,13,14};
        Personagem Character = new Personagem();
        Arvore1 arvore1 = new Arvore1();
        int numEntrada = 0;
        int mod = 0;
        String[] entrada = new String[1000];
        String[] nomes = new String[1000];
        try {
        for (int i = 0; i < 15; i++)
        {
        arvore1.inserir(array[i]);
        }
    }catch (Exception y)
    {
        MyIO.println("Erro ao Inserir Inteiros na Arvore");
    }     
        do {
            entrada[numEntrada] = MyIO.readLine();
        } while (isFim(entrada[numEntrada++]) == false);
        numEntrada--;
        try {
            for (int i = 0; i < numEntrada; i++) {
                Character.ler(entrada[i]);
                 mod = Character.altura % 15;
                if(arvore1.inserirElemento(mod,Character.clone()) == true)
                {
                arvore1.inserirElemento(mod,Character.clone());
                }
            }
        } catch (Exception f) {
            MyIO.println("Exception Error Leitura");
        }
        numEntrada = 0;
        // Lendo os nomes
        do {
            nomes[numEntrada] = MyIO.readLine();
        } while (isFim(nomes[numEntrada++]) == false);
        numEntrada--;
        // Verificando se os nomes existem na arvore
        
        for( i = 0; i < numEntrada; i++)
        {
        valor = false;
        arvore1.pesquisarInt(nomes[i]);
        if(valor)
        {
        MyIO.println(" SIM");
        }
        else
        {
        MyIO.println(" NÃO");    
        }

        }
        
        long tempoFinal = System.currentTimeMillis();
        Arq.openWrite("matrícula_arvoreBinaria.txt");
        Arq.println("637084\t"+"Numero de comparacoes: " + comp+ "\t Tempo de Execucao: " + (tempoFinal - tempoInicial));
        Arq.close();

        // Mostrar todos os elementos nas celulas
    }// Fim main
}
