class arquitetura
{


public static void main (String[] args)
{
int x = 637084;
int resp = (x % 1000/100 % 4);
MyIO.println(resp);

}

}