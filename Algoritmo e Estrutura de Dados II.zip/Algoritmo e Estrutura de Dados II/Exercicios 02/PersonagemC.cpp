#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define bool short
#define true 1
#define false 0
#define equals(a,b) (((strcmp(a,b) = 0) ? true : false))
#define NUMENTRADA 1000
#define TAMLINHA 1000

struct personagem
{
   char*nome;
   char*corDoCabelo;
   char*corDaPele;
   char*corDosOlhos;
   char*anoNascimento;
   char*genero;
   char*homeworld;
   int altura;
   double peso;
};
typedef struct personagem personagem;

bool isFim(char*palavra){
   return (strlen(palavra) >= 3 && palavra[0] == 'F' && palavra[1] == 'I' && palavra[2] == 'M');
}

void construtor(struct personagem *z)
{
   z->nome = "";
   z->corDoCabelo = "";
   z->corDaPele = "";
   z->corDosOlhos = "";
   z->anoNascimento = "";
   z->genero = "";
   z->homeworld = "";
   z->peso = 0;
   z->altura = 0;
}

//Clone   
personagem *clone (struct personagem *z)
{
   personagem *copia = (personagem*)malloc(sizeof(personagem));
//Malloc
   copia->nome = (char*)malloc(100*sizeof(char));
   copia->corDoCabelo = (char*)malloc(100*sizeof(char));
   copia->corDaPele = (char*)malloc(100*sizeof(char));
   copia->corDosOlhos = (char*)malloc(100*sizeof(char));
   copia->anoNascimento = (char*)malloc(100*sizeof(char));
   copia->genero = (char*)malloc(100*sizeof(char));
   copia->homeworld = (char*)malloc(100*sizeof(char));
//Salvando as String na copia
   strcpy(copia->nome,z->nome);
   //printf("%s\n",z->nome);
   strcpy(copia->corDoCabelo,z->corDoCabelo);
   //printf("%s\n",z->corDoCabelo);
   strcpy(copia->corDaPele,z->corDaPele);
  //printf("%s\n",z->corDaPele);
   strcpy(copia->corDosOlhos,z->corDosOlhos);
   //printf("%s\n",z->corDosOlhos);
   strcpy(copia->anoNascimento,z->anoNascimento);
  //printf("%s\n",z->anoNascimento);
   strcpy(copia->genero,z->genero);
   //printf("%s\n",z->genero);
   strcpy(copia->homeworld,z->homeworld);
  // printf("%s\n",z->homeworld);
   copia->altura = z->altura;
   //printf("%d\n",z->altura);
   copia->peso = z->peso;
   //printf("%g",z->peso);
   return copia;
}

void imprimir (struct personagem *y )
{
printf(" ## %s ## %d ## %g ## %s ## %s ## %s ## %s ## %s ## %s\n",
y->nome,y->altura,y->peso,y->corDoCabelo,y->corDaPele,y->corDosOlhos,y->anoNascimento,y->genero,y->homeworld);
}


void ler(char *palavra, personagem *y)
{
   
   char tmp [TAMLINHA]; 
   char nome [80],corDoCabelo[80],corDaPele[80],corDosOlhos[80],anoNascimento[80],genero[80],homeworld[80],peso[80],altura[80];
   char * aux;
   int tamanho = 0, i = 0,x = 0;
   tamanho = strlen(palavra)-1;
//Formatando a entrada no arquivo
   char ArquivoFormatado[strlen(tmp)];
   strcpy(ArquivoFormatado,palavra);
   ArquivoFormatado[tamanho] = '\0';
   FILE*arquivo = fopen(ArquivoFormatado,"r");
   fgets (tmp,TAMLINHA,arquivo);
   fclose(arquivo);
    //Nome
   aux = strstr(tmp,"name");
   i = aux - tmp + 8;
   while ( tmp[i] != '\'')
   {
      nome[x] = tmp[i];
      i++;
      x++;
   }
   nome[x] = '\0';
   y->nome = nome;
   x = 0;
   i = 0;
   //printf("## %s ",nome);
   
   //Altura
   aux = strstr(tmp,"height");
   i = aux - tmp + 10;
   while ( tmp[i] != '\'')
   {
      altura[x] = tmp[i];
      i++;
      x++;
   }
   altura[x] = '\0';
   y->altura = atoi(altura);
   x = 0;
   i = 0;
   //printf("## %s ",altura);
   
    //PESO
   aux = strstr(tmp,"mass");
   i = aux - tmp + 8;
   while ( tmp[i] != '\'')
   {
      peso[x] = tmp[i];
      i++;
      x++;
   }
   peso[x] = '\0';
   y->peso = atof(peso);
   x = 0;
   i = 0;
   //printf("## %g ",y->peso);
    
   //CorDaPele
   aux = strstr(tmp,"skin_color");
   i = aux - tmp + 14;
   while ( tmp[i] != '\'')
   {
      corDaPele[x] = tmp[i];
      i++;
      x++;
   }
   corDaPele[x] = '\0';
   y->corDaPele = corDaPele;
   x = 0;
   i = 0;
   //printf("## %s ",corDaPele);
   
   //CorDoCabelo
   aux = strstr(tmp,"hair_color");
   i = aux - tmp + 14;
   while ( tmp[i] != '\'')
   {
      corDoCabelo[x] = tmp[i];
      i++;
      x++;
   }
   corDoCabelo[x] = '\0';
   y->corDoCabelo = corDoCabelo;
   x = 0;
   i = 0;
   //printf("## %s ",corDoCabelo);
   
   //corDosOlhos
   aux = strstr(tmp,"eye_color");
   i = aux - tmp + 13;
   while ( tmp[i] != '\'')
   {
      corDosOlhos[x] = tmp[i];
      i++;
      x++;
   }
   corDosOlhos[x] = '\0';
   y->corDosOlhos = corDosOlhos;
   x = 0;
   i = 0;
   //printf("## %s ",corDosOlhos);
  
    //anoNascimento
   aux = strstr(tmp,"birth_year");
   i = aux - tmp + 14;
   while ( tmp[i] != '\'')
   {
      anoNascimento[x] = tmp[i];
      i++;
      x++;
   }
   anoNascimento[x] = '\0';
   y->anoNascimento = anoNascimento;
   x = 0;
   //printf("## %s ",anoNascimento);
   
   //genero
   aux = strstr(tmp,"gender");
   i = aux - tmp + 10;
   while ( tmp[i] != '\'')
   {
      genero[x] = tmp[i];
      i++;
      x++;
   }
   genero[x] = '\0';
   y->genero = genero;
   x = 0;
   //printf("## %s ",genero);
   
   //homeworld
   aux = strstr(tmp,"homeworld");
   i = aux - tmp + 13;
   while ( tmp[i] != '\'')
   {
      homeworld[x] = tmp[i];
      i++;
      x++;
   }
   homeworld[x] = '\0';
   y->homeworld = homeworld;
   x = 0;
   //printf("## %s ##\n",homeworld);
  
}

void method01 ( )
{
   char palavra[NUMENTRADA][TAMLINHA];
   int entrada = 0, i = 0;
   personagem *Personagem;
   Personagem = (personagem*)malloc(sizeof(personagem));
   do
   {
   //Entrada padrao
      fgets (palavra[entrada],TAMLINHA,stdin);
   }
   while(isFim(palavra[entrada++]) == false);
   entrada--;
   for ( i = 0; i < entrada; i++)
   { 
      ler(palavra[i],Personagem);  
      Personagem = clone(Personagem);
      imprimir(Personagem);
   }
   free(Personagem);
}

int main ( )
{
   method01 ( );
}



