class MenorDaPilhaJava
{

    static class Pilha
   {
      public int array [];
	  public int n;
   
      public Pilha (int tam)
      {
         array = new int[tam];
         n = 0;
      }

	 public void inserirFim(int x) throws Exception {

		//validar insercao
		if(n >= array.length){
		   throw new Exception("Erro ao inserir!");
		}

		array[n] = x;
		n++;
	 }

     public int removerFim() throws Exception 
     {

		if (n == 0) {
		   throw new Exception("EMPTY");
		}

		return array[--n];
     }
     public int menorValor()
     {
      int menor = array[0];
      if ( n == 0 )
      {
       MyIO.println("EMPTY");   
      }
      for (int y = 0; y < n; y++)
      {
      if (array[y] < menor)
      {
      menor = array[y];    
      }      
      }
      return menor;   
     } 
   }


public static void main(String[] args)    
{
int entrada = 0;
String [] tmp = new String [100];
entrada = MyIO.readInt();
Pilha pilha = new Pilha(100);
for (int y = 0; y < entrada; y++)
{
tmp[y] = MyIO.readLine();

if (tmp[y].charAt(0) == 'P' && tmp[y].charAt(1) == 'U')
{
tmp[y] = tmp[y].replace("PUSH ","");
int numero = Integer.parseInt(tmp[y]);
try
{
pilha.inserirFim(numero);
}catch (Exception a) 
{
MyIO.println("Erro ao inserir presente");
}
}

if (tmp[y].equals("MIN"))
{
int resp = 0;
resp = pilha.menorValor();
MyIO.println(resp);
}

if (tmp[y].equals("POP"))
{
try
{
pilha.removerFim();
}catch(Exception b)
{
MyIO.println("Erro ao remover presente");
}
}
}//fim for
}
}