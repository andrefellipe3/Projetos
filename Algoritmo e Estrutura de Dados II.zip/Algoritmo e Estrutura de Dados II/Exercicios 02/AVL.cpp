#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
#include <err.h>
#include <assert.h>
#include <limits.h>
#define bool short
#define true 1
#define false 0
#define equals (a, b)(((strcmp(a, b) == 0) ? true : false))
#define NUMENTRADA 1000
#define TAMLINHA 1000

bool repos = false;
double tempo;
int comp = 0;
int mov = 0;

typedef struct Personagem {
   char *nome;
   char *corDoCabelo;
   char *corDaPele;
   char *corDosOlhos;
   char *anoNascimento;
   char *genero;
   char *homeworld;
   double peso;
   int altura;
} Personagem;

void construir1(struct Personagem *x) {
   x->nome = "";
   x->corDoCabelo = "";
   x->corDaPele = "";
   x->corDosOlhos = "";
   x->anoNascimento = "";
   x->genero = "";
   x->homeworld = "";
   x->peso = 0;
   x->altura = 0;
}

Personagem *clone(struct Personagem *x) {
   Personagem *resp = (Personagem *)malloc(sizeof(Personagem));

   // malloc
   resp->nome = (char *)malloc(100 * sizeof(char));
   resp->corDoCabelo = (char *)malloc(100 * sizeof(char));
   resp->corDaPele = (char *)malloc(100 * sizeof(char));
   resp->corDosOlhos = (char *)malloc(100 * sizeof(char));
   resp->anoNascimento = (char *)malloc(100 * sizeof(char));
   resp->genero = (char *)malloc(100 * sizeof(char));
   resp->homeworld = (char *)malloc(100 * sizeof(char));

   // char*
   strcpy(resp->nome, x->nome);
   strcpy(resp->corDoCabelo, x->corDoCabelo);
   strcpy(resp->corDaPele, x->corDaPele);
   strcpy(resp->corDosOlhos, x->corDosOlhos);
   strcpy(resp->anoNascimento, x->anoNascimento);
   strcpy(resp->genero, x->genero);
   strcpy(resp->homeworld, x->homeworld);

   // double
   resp->peso = x->peso;

   // int
   resp->altura = x->altura;

   return resp;
}

void ler(char *nomeArq, struct Personagem *x) {
   construir1(x);
   char temp[TAMLINHA];  
   char dados[TAMLINHA]; 
   char *aux;            
   int i, j;            
   int tam;              
   i = j = 0;

   // ajustando a char*
   tam = strlen(nomeArq) - 1;
   char arqFormatado[strlen(temp)];
   strcpy(arqFormatado, nomeArq);
   arqFormatado[tam] = '\0';

   if (repos)
      strcpy(arqFormatado, nomeArq);
   FILE *Arq;
   Arq = fopen(arqFormatado, "r");
   fgets(dados, TAMLINHA, Arq);
   fclose(Arq);

   // nome
   for (i = 0; i < TAMLINHA; i++) // limpar temp
      temp[i] = 0;
   j = 0;

   aux = strstr(dados, "name");
   i = aux - dados + 8;
   while (dados[i] != '\'')
   {
      temp[j] = dados[i];
      i++;
      j++;
   }
   // ajustando a char*
   char nomeFormatado[strlen(temp)];
   strcpy(nomeFormatado, temp);
   tam = strlen(nomeFormatado);
   nomeFormatado[tam] = '\0';
   x->nome = nomeFormatado;
   for (i = 0; i < TAMLINHA; i++) // limpar temp
      temp[i] = 0;
   j = 0;

   // corDoCabelo
   aux = strstr(dados, "hair_color");
   i = aux - dados + 14;
   while (dados[i] != '\'')
   {
      temp[j] = dados[i];
      i++;
      j++;
   }
   // ajustando a char*
   char corDoCabeloFormatado[strlen(temp)];
   strcpy(corDoCabeloFormatado, temp);
   tam = strlen(corDoCabeloFormatado);
   corDoCabeloFormatado[tam] = '\0';
   x->corDoCabelo = corDoCabeloFormatado;
   for (i = 0; i < TAMLINHA; i++) // limpar temp
      temp[i] = 0;
   j = 0;

   // corDaPele
   aux = strstr(dados, "skin_color");
   i = aux - dados + 14;
   while (dados[i] != '\'')
   {
      temp[j] = dados[i];
      i++;
      j++;
   }
   // ajustando a char*
   char corDaPeleFormatado[strlen(temp)];
   strcpy(corDaPeleFormatado, temp);
   tam = strlen(corDaPeleFormatado);
   corDaPeleFormatado[tam] = '\0';
   x->corDaPele = corDaPeleFormatado;
   for (i = 0; i < TAMLINHA; i++) // limpar temp
      temp[i] = 0;
   j = 0;

   // corDosOlhos
   aux = strstr(dados, "eye_color");
   i = aux - dados + 13;
   while (dados[i] != '\'')
   {
      temp[j] = dados[i];
      i++;
      j++;
   }
   // ajustando a char*
   char corDosOlhosFormatado[strlen(temp)];
   strcpy(corDosOlhosFormatado, temp);
   tam = strlen(corDosOlhosFormatado);
   corDosOlhosFormatado[tam] = '\0';
   x->corDosOlhos = corDosOlhosFormatado;
   for (i = 0; i < TAMLINHA; i++) // limpar temp
      temp[i] = 0;
   j = 0;

   // anoNascimento
   aux = strstr(dados, "birth_year");
   i = aux - dados + 14;
   while (dados[i] != '\'')
   {
      temp[j] = dados[i];
      i++;
      j++;
   }
   // ajustando a char*
   char anoNascimentoFormatado[strlen(temp)];
   strcpy(anoNascimentoFormatado, temp);
   tam = strlen(anoNascimentoFormatado);
   anoNascimentoFormatado[tam] = '\0';
   x->anoNascimento = anoNascimentoFormatado;
   for (i = 0; i < TAMLINHA; i++) // limpar temp
      temp[i] = 0;
   j = 0;

   // genero
   aux = strstr(dados, "gender");
   i = aux - dados + 10;
   while (dados[i] != '\'')
   {
      temp[j] = dados[i];
      i++;
      j++;
   }
   // ajustando a char*
   char generoFormatado[strlen(temp)];
   strcpy(generoFormatado, temp);
   tam = strlen(generoFormatado);
   generoFormatado[tam] = '\0';
   x->genero = generoFormatado;
   for (i = 0; i < TAMLINHA; i++) // limpar temp
      temp[i] = 0;
   j = 0;

   // homeworld
   aux = strstr(dados, "homeworld");
   i = aux - dados + 13;
   while (dados[i] != '\'')
   {
      temp[j] = dados[i];
      i++;
      j++;
   }
  
   char homeworldFormatado[strlen(temp)];
   strcpy(homeworldFormatado, temp);
   tam = strlen(homeworldFormatado);
   homeworldFormatado[tam] = '\0';
   x->homeworld = homeworldFormatado;
   for (i = 0; i < TAMLINHA; i++) 
      temp[i] = 0;
   j = 0;

   // peso
   aux = strstr(dados, "mass");
   i = aux - dados + 8;
   while (dados[i] != '\'')
   {
      temp[j] = dados[i];
      i++;
      j++;
   }

   char pesoFormatado[strlen(temp)];
   strcpy(pesoFormatado, temp);
   tam = strlen(pesoFormatado);
   pesoFormatado[tam] = '\0';
   x->peso = atof(pesoFormatado);
   for (i = 0; i < TAMLINHA; i++) 
      temp[i] = 0;
   j = 0;

   // altura
   aux = strstr(dados, "height");
   i = aux - dados + 10;
   while (dados[i] != '\'')
   {
      temp[j] = dados[i];
      i++;
      j++;
   }
 
   char alturaFormatado[strlen(temp)];
   strcpy(alturaFormatado, temp);
   tam = strlen(alturaFormatado);
   alturaFormatado[tam] = '\0';
   x->altura = atoi(alturaFormatado);
   for (i = 0; i < TAMLINHA; i++)
      temp[i] = 0;
   j = 0;
}

struct node_struct
{
	struct node_struct * esq;
	struct node_struct * dir;
	struct Personagem *elemento;
};

typedef struct node_struct node;

struct tree_struct
{
	struct node_struct * raiz;
};

typedef struct tree_struct tree;

void liberar_memoria_impl ( node * node_ptr );

void liberar_memoria ( tree * tree_ptr );

tree * init_tree ( );

node * init_node ( struct Personagem *valor );

int altura ( node * node_ptr );

int fator_bal ( node * node_ptr );

node * rotacionar_esq_esq ( node * node_ptr );

node * rotationar_esq_dir ( node * node_ptr );

node * rotacionar_dir_esq ( node * node_ptr );

node * rotacionar_dir_dir ( node * node_ptr );

node * balancear_node ( node * node_ptr );

void balancear_tree ( tree * tree_ptr );

void inserir ( tree * tree_ptr, struct Personagem *valor );

node * encontrar_valor ( tree * tree, struct Personagem *valor );

void avl_traverse_node_dfs ( node * node, int depth );

void avl_traverse_dfs ( tree * tree );

int max(int num1, int num2)
{
    return (num1 > num2 ) ? num1 : num2;
}

void liberar_memoria_impl ( node * node_ptr )
{
	if ( node_ptr == NULL )
		return;

	liberar_memoria_impl ( node_ptr->esq );
	liberar_memoria_impl ( node_ptr->dir );

	//free ( node_ptr );
}


void liberar_memoria ( tree * tree_ptr )
{
	liberar_memoria_impl ( tree_ptr->raiz );
}


tree * init_tree ( )
{
	tree * arvore = NULL;
	if ( ( arvore = (tree *)malloc ( sizeof ( tree ) ) ) == NULL )
	{
		return NULL;
	}

	arvore->raiz = NULL;

	return arvore;
}

node * init_node ( struct Personagem *elemento )
{
	node * No_ptr;

	No_ptr = (node *)malloc ( sizeof ( node ) );
	if ( No_ptr == NULL )
	{
		system ( "pause" );
	}

	No_ptr->esq = NULL;
	No_ptr->dir = NULL;
	No_ptr->elemento = elemento;

	return No_ptr;
}

int altura ( node * No_ptr )
{
	int altura_esq = 0;
	int altura_dir = 0;

	if ( No_ptr->esq )
		altura_esq = altura ( No_ptr->esq );

	if ( No_ptr->dir )
		altura_dir = altura ( No_ptr->dir );

	return max ( altura_dir, altura_esq ) + 1;
}


int fator_bal ( node * No_ptr )
{
	int fator = 0;

	if ( No_ptr->esq )
		fator += altura ( No_ptr->esq );

	if ( No_ptr->dir )
		fator -= altura ( No_ptr->dir );

	return fator;
}


node * rotacionar_esq_esq ( node * No_ptr )
{
	node * temp_ptr = No_ptr;
	node * esq_ptr = temp_ptr->esq;

	temp_ptr->esq = esq_ptr->dir;
	esq_ptr->dir = temp_ptr;

	return esq_ptr;
}

node * rotationar_esq_dir (node * No_ptr )
{
	node * temp_ptr = No_ptr;
	node * esq_ptr = temp_ptr->esq;
	node * dir_ptr = esq_ptr->dir;

	temp_ptr->esq = dir_ptr->dir;
	esq_ptr->dir = dir_ptr->esq;
	dir_ptr->esq = esq_ptr;
	dir_ptr->dir = temp_ptr;

	return dir_ptr;
}

node * rotacionar_dir_esq ( node * No_ptr )
{
	node * temp_ptr = No_ptr;
	node * dir_ptr = temp_ptr->dir;
	node * esq_ptr = dir_ptr->esq;

	temp_ptr->dir = esq_ptr->esq;
	dir_ptr->esq = esq_ptr->dir;
	esq_ptr->dir = dir_ptr;
	esq_ptr->esq = temp_ptr;

	return esq_ptr;
}


node * rotacionar_dir_dir ( node * No_ptr )
{
	node * temp_ptr = No_ptr;
	node * dir_ptr = temp_ptr->dir;

	temp_ptr->dir = dir_ptr->esq;
	dir_ptr->esq = temp_ptr;

	return dir_ptr;
}

node * balancear_node ( node * No_ptr )
{
	node * node_balanceado = NULL;

	if ( No_ptr->esq )
		No_ptr->esq = balancear_node ( No_ptr->esq );

	if ( No_ptr->dir )
		No_ptr->dir = balancear_node ( No_ptr->dir );

	int fator = fator_bal ( No_ptr );

	if ( fator >= 2 )
	{
		/* pesando pra esquerda */

		if ( fator_bal ( No_ptr->esq ) <= -1 )
			node_balanceado = rotationar_esq_dir ( No_ptr );
		else
			node_balanceado = rotacionar_esq_esq ( No_ptr );

	}
	else if ( fator <= -2 )
	{
		/* pesando pra direita */

		if ( fator_bal ( No_ptr->dir ) >= 1 )
			node_balanceado = rotacionar_dir_esq ( No_ptr );
		else
			node_balanceado = rotacionar_dir_dir ( No_ptr );

	}
	else
	{
		node_balanceado = No_ptr;
	}

	return node_balanceado;
}


void balancear_tree ( tree * arvore_ptr )
{
	node * nova_raiz = NULL;

	nova_raiz = balancear_node ( arvore_ptr->raiz );

	if ( nova_raiz != arvore_ptr->raiz )
	{
		arvore_ptr->raiz = nova_raiz;
	}
}

void inserir ( tree * arvore_ptr, struct Personagem *elemento )
{
	node * novo_node_ptr = NULL;
	node * next_ptr = NULL;
	node * last_ptr = NULL;

	if ( arvore_ptr->raiz == NULL )
	{
		novo_node_ptr = init_node ( elemento );
		arvore_ptr->raiz = novo_node_ptr;
	}
	else
	{
		next_ptr = arvore_ptr->raiz;

		while ( next_ptr != NULL )
		{
			last_ptr = next_ptr;

			if ( strcmp (elemento->nome , next_ptr->elemento->nome) < 0 )
			{
				next_ptr = next_ptr->esq;

			}
			else if ( strcmp (elemento->nome , next_ptr->elemento->nome) > 0 )
			{
				next_ptr = next_ptr->dir;
			}
			else if ( strcmp (elemento->nome , next_ptr->elemento->nome) == 0 )
			{
				return;
			}
		}

		novo_node_ptr = init_node ( elemento );

		if ( strcmp (elemento->nome , last_ptr->elemento->nome) < 0 )
			last_ptr->esq = novo_node_ptr;

		if ( strcmp (elemento->nome , last_ptr->elemento->nome) > 0 )
			last_ptr->dir = novo_node_ptr;

	}

	balancear_tree ( arvore_ptr );
}


bool isFim(char *s) {
   return (strlen(s) >= 3 && s[0] == 'F' && s[1] == 'I' && s[2] == 'M');
}

void log() 
{
   clock_t begin = clock();
   FILE *Arq;
   Arq = fopen("matrícula_avl.txt", "w");
   fprintf(Arq, "637084\t%g\t%d", tempo, comp);
   fclose(Arq);
}

int resultado = false;
char *goal = "";
void createGoal ()
{
   goal = (char *)malloc(500 * sizeof(char));
}
void destroyGoal ()
{
   //free (goal);
   goal = NULL;
}

      char* pesquisaBinariaRec(node *i, char* procurado, char* way, char* resp) 
      {

         comp++;
         if (i != NULL) 
         {
            
            if ( strcmp (i->elemento->nome , procurado) > 0 ) 
            {

               strcat(goal, " esq");
               resp = pesquisaBinariaRec(i->esq, procurado, "esq", resp); 
               comp += 1;
            }

            else if ( strcmp (i->elemento->nome , procurado) < 0 ) {
               strcat(goal, " dir");
               resp = pesquisaBinariaRec(i->dir, procurado, "dir", resp); 
               comp += 2;
            }

            else if ( strcmp (i->elemento->nome , procurado) == 0 ) 
            {
               resultado = true;
               comp += 3;
            }

         }

         return goal;
      }

      char* pesquisaBinaria(tree * arvore_ptr, char* procurado) 
      {
         // ajustando a char*
            int tam = strlen(procurado) - 1;
            char procuradoFormatado[500];
            strcpy(procuradoFormatado, procurado);
            procuradoFormatado[tam] = '\0';

         char* resp = "";
         strcat(goal, procuradoFormatado);
         strcat(goal, " raiz");
         resp = pesquisaBinariaRec(arvore_ptr->raiz, procuradoFormatado, "raiz", "raiz");
         if (resultado == true)
            strcat(goal, " SIM");
         else
            strcat(goal, " NÃO");
         resultado = false;
         return resp;
      }

int main(int argc, char **argv) 
{
   clock_t begin = clock();
   char entrada[NUMENTRADA][TAMLINHA];
   int numEntrada = 0;
   tree * arvore_ptr = init_tree ( );
   Personagem * Character;
    Character = (Personagem *)malloc(sizeof(Personagem));
   char linha[100];

   // Leitura da entrada padrao
   do {
      fgets(entrada[numEntrada], TAMLINHA, stdin);
   } while (isFim(entrada[numEntrada++]) == false);
   numEntrada--; //Desconsiderar ultima linha contendo a palavra FIM

   // loop para impressao
   for (int i = 0; i < numEntrada; i++) 
   {
      ler(entrada[i],  Character);
      inserir ( arvore_ptr, clone(Character) );
   }

   fgets(linha, sizeof(linha), stdin);
   char* pointer = linha;

   while (isFim(linha) == false) 
   {
      createGoal ();
      printf("%s\n", pesquisaBinaria(arvore_ptr, linha));
      strcpy(linha,"");
      fgets(linha, sizeof(linha), stdin);
      pointer = linha;
      destroyGoal();
   }

   clock_t end = clock();
   tempo = (double)(end - begin);
   log();

}