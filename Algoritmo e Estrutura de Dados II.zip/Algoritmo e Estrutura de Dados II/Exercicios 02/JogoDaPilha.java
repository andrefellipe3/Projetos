public class JogoDaPilha {
    
public static void metodo ()    
{
int[] pilha1 = new int[100];
int[] pilha2 = new int[100];
int[]pilha3  = new int[100];
int[]resp  = new int[100];
int resposta = 0;
int soma = 0,x = 0;
int n = 1;
while ( n != 0)
{
if (n == 0)
{
break;
}    
n = 0;
n = MyIO.readInt();
for(int i = 0; i < n; i++)
{
pilha1[i] = MyIO.readInt();
pilha2[i] = MyIO.readInt();
pilha3[i] = MyIO.readInt();
}

for (int i = 0; i < n; i++)
{
soma = pilha1[i] + pilha2[i] + pilha3[i];

if ( soma % 3 == 0)
{
resposta = 1;  
}
else
{
i = n-1;    
}
}
resp[x] = resposta;
x++;
resposta = 0;
}//while
for ( int i = 0; i < x-1; i++)
{
    MyIO.println("" + resp[i]);
}
}
public static void main (String[] args)
{
metodo();    
}  

}
