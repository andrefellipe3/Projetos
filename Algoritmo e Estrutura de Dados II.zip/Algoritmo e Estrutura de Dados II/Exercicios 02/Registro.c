#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define bool short
#define true 1
#define false 0
#define equals(a,b) (((strcmp(a,b) == 0) ? true : false))
#define NUMENTRADA 1000
#define TAMLINHA 1000

struct personagem
{
   char*nome;
   char*corDoCabelo;
   char*corDaPele;
   char*corDosOlhos;
   char*anoNascimento;
   char*genero;
   char*homeworld;
   int altura;
   double peso;
};
typedef struct personagem personagem;

bool isFim(char*palavra){
   return (strlen(palavra) >= 3 && palavra[0] == 'F' && palavra[1] == 'I' && palavra[2] == 'M');
}

void construtor(struct personagem *z)
{
   z->nome = "";
   z->corDoCabelo = "";
   z->corDaPele = "";
   z->corDosOlhos = "";
   z->anoNascimento = "";
   z->genero = "";
   z->homeworld = "";
   z->peso = 0;
   z->altura = 0;
}

void imprimir (struct personagem *y )
{
   printf(" ## %s ## %d ## %g ## %s ## %s ## %s ## %s ## %s ## %s ## \n",
   y->nome,y->altura,y->peso,y->corDoCabelo,y->corDaPele,y->corDosOlhos,y->anoNascimento,y->genero,y->homeworld);
}

//Clone   
personagem *clone (struct personagem *y)
{
   personagem *copia = (personagem*)malloc(sizeof(personagem));
//Malloc
   copia->nome = (char*)malloc(100*sizeof(char));
   copia->corDoCabelo = (char*)malloc(100*sizeof(char));
   copia->corDaPele = (char*)malloc(100*sizeof(char));
   copia->corDosOlhos = (char*)malloc(100*sizeof(char));
   copia->anoNascimento = (char*)malloc(100*sizeof(char));
   copia->genero = (char*)malloc(100*sizeof(char));
   copia->homeworld = (char*)malloc(100*sizeof(char));
//Salvando as String na copia
   copia->nome = y->nome;
   copia->corDoCabelo = y->corDoCabelo;
   copia->corDaPele = y->corDaPele;
   copia->corDosOlhos = y-> corDosOlhos;
   copia->anoNascimento = y->anoNascimento;
   copia->genero = y->genero;
   copia->homeworld = y->homeworld;
   copia->altura = y->altura;
   copia->peso = y->peso;
   return copia;
}

void ler(char *palavra, personagem *y)
{ 
   construtor(y);
   char tmp [TAMLINHA]; 
   char info [TAMLINHA];
   char * aux;
   int tamanho = 0, i = 0,x = 0,z = 0;
   tamanho = strlen(palavra)-1;
//Formatando a entrada no arquivo
   strcpy(info,palavra);
   info[tamanho] = '\0';
   FILE*arquivo = fopen(info,"r");
   if ( arquivo != NULL)
   {
      fgets (tmp,TAMLINHA,arquivo);
      fclose(arquivo);
    //Nome
      aux = strstr(tmp,"name");
      i =  aux - tmp + 8;
      char NomeFormatado[TAMLINHA];
      while ( tmp[i] != '\'')
      {
         NomeFormatado[x] = tmp[i];
         i++;
         x++;
      }
      NomeFormatado[x] = '\0';
      y->nome = NomeFormatado;
      
   //Altura
      aux = strstr(tmp,"height");
      i = aux - tmp + 10;
      char AlturaFormatado[TAMLINHA];
      x = 0;
      while ( tmp[i] != '\'')
      {
         AlturaFormatado[x] = tmp[i];
         i++;
         x++;
      }
      AlturaFormatado[x] = '\0';
      y->altura = atoi(AlturaFormatado);
   
    //PESO
      aux = strstr(tmp,"mass");
      i = aux - tmp + 8;
      char PesoFormatado[TAMLINHA];
      x = 0;
      while ( tmp[i] != '\'')
      {
        PesoFormatado[x] = tmp[i];
         i++;
         x++;
      }
      PesoFormatado[x] = '\0';
      y->peso = atof(PesoFormatado);
    
   //CorDoCabelo
      aux = strstr(tmp,"hair_color");
      i = aux - tmp + 14;
      char CorDoCabeloFormatado[TAMLINHA];
      x = 0;
      while ( tmp[i] != '\'')
      {
         CorDoCabeloFormatado[x] = tmp[i];
         i++;
         x++;
      }
      CorDoCabeloFormatado[x] = '\0';
      y->corDoCabelo = CorDoCabeloFormatado;

   //CorDaPele
      aux = strstr(tmp,"skin_color");
      i = aux - tmp + 14;
      char CorDaPeleFormatado[TAMLINHA];
      x = 0;
      while ( tmp[i] != '\'')
      {
         CorDaPeleFormatado[x] = tmp[i];
         i++;
         x++;
      }
      CorDaPeleFormatado[x] = '\0';
      y->corDaPele = CorDaPeleFormatado;
   
   //corDosOlhos
      aux = strstr(tmp,"eye_color");
      i = aux - tmp + 13;
      char CorDosOlhosFormatado[TAMLINHA];
      x = 0;
      while ( tmp[i] != '\'')
      {
         CorDosOlhosFormatado[x] = tmp[i];
         i++;
         x++;
      }
     CorDosOlhosFormatado[x] = '\0';
      y->corDosOlhos = CorDosOlhosFormatado;
   
    //anoNascimento
      aux = strstr(tmp,"birth_year");
      i = aux - tmp + 14;
      char anoNascimentoFormatado[TAMLINHA];
      x = 0;
      while ( tmp[i] != '\'')
      {
         anoNascimentoFormatado[x] = tmp[i];
         i++;
         x++;
      }
      anoNascimentoFormatado[x] = '\0';
      y->anoNascimento = anoNascimentoFormatado;
 
   //genero
      aux = strstr(tmp,"gender");
      i = aux - tmp + 10;
      char generoFormatado[TAMLINHA];
      x = 0;
      while ( tmp[i] != '\'')
      {
         generoFormatado[x] = tmp[i];
         i++;
         x++;
      }
      generoFormatado[x] = '\0';
      y->genero = generoFormatado;

   //homeworld
      aux = strstr(tmp,"homeworld");
      i = aux - tmp + 13;
      char homeworldFormatado[TAMLINHA];
      x = 0;
      while ( tmp[i] != '\'')
      {
        homeworldFormatado[x] = tmp[i];
         i++;
         x++;
      }
      homeworldFormatado[x] = '\0';
      y->homeworld = homeworldFormatado;
   }
}

void method01 ( )
{
   char palavra[NUMENTRADA][TAMLINHA];
   int entrada = 0, i = 0;
   personagem *Personagem;
   Personagem = (personagem*)malloc(sizeof(personagem));
   do
   {
   //Entrada padrao
      fgets (palavra[entrada],TAMLINHA,stdin);
   }
   while(isFim(palavra[entrada++]) == false);
   entrada--;
   for ( i = 0; i < entrada; i++)
   { 
      ler(palavra[i],Personagem);  
      clone(Personagem);
      imprimir(Personagem);
   }
}

int main ( )
{
   method01 ( );
   return 0;
}
