class balancoParenteses
{

   public static boolean isFim (String s)
   {
      return(s.length() >= 3 && s.charAt(0)=='F' &&
         s.charAt(1)=='I'&&s.charAt(2)=='M');
   }

   public static boolean identificar (String s)
   {
      boolean resultado = false;
      int count1 = 0,count2 = 0;   
      if (s.charAt(0) == ')')
      {
      return resultado;
      }
      if (s.charAt(s.length()-1) == '(')
      {
      return resultado;
      }
      
      for ( int i = 0; i < s.length(); i++)
      {
         if (s.charAt(i) == ')')
         {
            count1++;
         }
          if (s.charAt(i) == '(' )
         {
            count2++;
         }

      }
            
      if ( count2 == count1)
      {
         resultado = true;
      }
      return resultado;
   }

   public static void method01 ( )
   {
      int numEntrada = 0;
      String[] palavra = new String [1000];
      String[] resposta = new String [1000];
      do
      {
         boolean resultado = true;
         palavra[numEntrada] = MyIO.readLine();
         resultado = identificar(palavra[numEntrada]);
         if( resultado == true)
         {
           resposta[numEntrada] = "correto";
         }
         if (resultado == false)
         {
            resposta[numEntrada] = "incorreto";
         }
      }
      while(isFim(palavra[numEntrada++]) == false);
      numEntrada--;
      for ( int i = 0; i < numEntrada; i++)
      {
      MyIO.println(resposta[i]);
      }
   }



   public static void main (String[] args)
   {
      method01 ();
   }
}