class Palindromo
{
   
   public static boolean Fim( String s )
   {
      return (s.length() >= 3 && s.charAt(0)=='F' &&
         s.charAt(1)=='I'&&s.charAt(2)=='M');
   }
   
   public static boolean testePalindromo (String palavra)
   {
      boolean resultado = true;
      int y = 0, x = 0,tamanho = 0;
      tamanho = palavra.length();
      x = tamanho-1;
      for ( y = 0; y < tamanho; y++)
      { 
          //Teste pra descobrir se a String e palindromo ou nao.
         if ( palavra.charAt(y) != palavra.charAt(x))
         {
          
            resultado = false;
            return resultado;
         }
         x--;
      }
      return resultado;
   }


   public static void method01 ( )
   {
      String[] palavra = new String[1000];
      String[] resposta = new String[1000];
      int numentrada = 0,y = 0;
      boolean resultado = true;
      do
      {
         palavra[numentrada] = MyIO.readLine();
         resultado = testePalindromo(palavra[numentrada]);
         if (resultado == false)
         {
            resposta[numentrada] = "NAO";
         }
         else
         {
            resposta[numentrada] = "SIM";
         }
      }
      while (Fim(palavra[numentrada++]) == false);
      numentrada--;   
      
      for ( y = 0; y < numentrada; y++)
      {
         MyIO.println(" "+resposta[y]);
      }
   }
      
   public static void main (String args[])
   {
      method01( );
   }
}
