class CiframentoCesar
{
   public static boolean isFim (String palavra)
   {
  return (palavra.length() >= 3 && palavra.charAt(0) == 'F' && palavra.charAt(1) == 'I' && palavra.charAt(2) == 'M');
}
   public static String criptografia (String s)
   {
   String resultado = " ";
   for (int i = 0; i < s.length(); i++)
   {
   //Convertendo um caractere para inteiro(ASCII)
   int num = (int)s.charAt(i);
   num = num+3;
   char tmp = (char)num;
   resultado = resultado+tmp;
   }
   return resultado;
   }
 
   public static void method01 ( )
   {
   String[]entrada = new String[1000];
   int numEntrada = 0;
    //Leitura da entrada padrao
      do {
         entrada[numEntrada] = MyIO.readLine();
      } while (isFim(entrada[numEntrada++]) == false);
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
   
      //La�o para impressao
      for(int i = 0; i < numEntrada; i++)
      {
         MyIO.println(criptografia(entrada[i]));
      }
   }
   
   public static void main (String args[])
   {
      method01();
   }
}