class Espelho
{

public static boolean isFim (String s)
{
return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
}

public static String espelho (String palavra)
{
String branco = " ";
if (palavra.length() >= 3 && palavra.charAt(0) == 'F' && palavra.charAt(1) == 'I' && palavra.charAt(2) == 'M')
{
return branco;
}
String[] separar = new String [1000]; 
separar = palavra.split(" ");
String resultado = "",s = "",x = "";
s = separar[0];
x = separar[1];
String tmp = "";
int valor1 = Integer.parseInt(s);
int valor2 = Integer.parseInt(x);
for (int i = valor1; i < valor2+1; i++)
{
tmp = tmp+i;
}
resultado = resultado + tmp;

for (int i = tmp.length()-1; i >= 0; i--)
{
resultado = resultado+tmp.charAt(i);
}
return resultado;
}

public static void method01 ( )
{
int numEntrada = 0;
String[] palavra = new String [1000];
String[] separar = new String [1000];
do
{
String resultado = "";
palavra[numEntrada] = MyIO.readLine();
separar = palavra[numEntrada].split(" ");
resultado = espelho(palavra[numEntrada]);
MyIO.println(resultado);
}
while(isFim(palavra[numEntrada++]) == false);
}

public static void main (String[] args)
{
method01 ( );
}
}