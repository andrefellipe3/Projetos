import java.util.Random;
class AlteracaoAleatoria
{
   static Random gerador = new Random( ) ;
   
   public static boolean isFim (String palavra)
   {
      return (palavra.length() >= 3 && palavra.charAt(0) == 'F' && palavra.charAt(1) == 'I' && palavra.charAt(2) == 'M');
   }

   //Funcao pra gerar um caractere aleatorio
   public static char gerarRandom ( )
   {
      char var = ' ';
      var = ((char)('a'+(Math.abs(gerador.nextInt())%26)));
      return var;
   }

   public static String Alterar(String s,char x,char y)
   {
      String resposta = " ";
      for ( int i = 0; i < s.length(); i++)
      {
         //Trocando o caractere padrao pelo aleatorio
         if ( s.charAt(i) == x )
         {
            resposta = resposta+y;
         }
         else
         {
            resposta = resposta+s.charAt(i);
         }
      }
      return resposta;
   }

   public static void method01 ( )
   {
      gerador.setSeed ( 4 ) ;
      String[] entrada = new String[1000];
      int numEntrada = 0;
   //Leitura da entrada padrao
      do {
         entrada[numEntrada] = MyIO.readLine();
        
      } while (isFim(entrada[numEntrada++]) == false);
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
   
   //La�o para impressao
      for(int i = 0; i < numEntrada; i++)
      {
         char x = ' ';
         char y = ' ';
         x = gerarRandom();
         y = gerarRandom();
         MyIO.println(Alterar(entrada[i],x,y));  
      }
   }
      
   public static void main (String args[])
   {
      method01();       
   }
}