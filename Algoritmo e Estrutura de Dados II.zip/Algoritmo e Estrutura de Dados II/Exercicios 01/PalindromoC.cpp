#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#define NUMENTRADA 1000
#define TAMLINHA 1000


bool Fim(char*palavra){
   return (strlen(palavra) >= 3 && palavra[0] == 'F' && palavra[1] == 'I' && palavra[2] == 'M');
}

bool palindromo (char*palavra)
{
   bool resultado = true; 
   int tamanho = 0,y = 0,x = 0;
   tamanho = strlen(palavra)-1;
   x = tamanho-1;;
   for ( y = 0; y < tamanho; y++)
   {
      //Teste pra saber se a palavra � um palindromo
      if (palavra[y] != palavra[x])
      {
         resultado = false;
         return resultado;
      }
      x--;
   }
   //Se passar no teste acima ele volta verdadeiro
   return resultado;
}


void method01 ( )
{
   char palavra[NUMENTRADA][TAMLINHA];   
   int numentrada = 0,y = 0;
   bool resultado = true;
   do
   {
      //Entrada padrao
      fgets(palavra[numentrada],TAMLINHA,stdin);
      resultado = palindromo(palavra[numentrada]);
      
      if (Fim(palavra[numentrada]) == true)
      {
      printf(" ");
      }
      
      else if (resultado == false)
      {  
         printf("NAO\n");
      }
      
      else
      {
         printf("SIM\n");
      }
   }
      while (Fim(palavra[numentrada++]) == false);
   numentrada--;   
}

int main (int argc,char**argv )
{
   method01();
}