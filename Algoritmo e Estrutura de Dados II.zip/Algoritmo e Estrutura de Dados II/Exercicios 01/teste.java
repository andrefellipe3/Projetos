 class Guj 
{

private String palavra;

public int altera(String palavra){
	
	int numero;
	
	numero = Integer.parseInt(palavra);
	
	return numero;
}

public static void main(String[] args) {
	
	Guj g = new Guj();
	
	System.out.println(g.altera("10"));
	
	
}
}