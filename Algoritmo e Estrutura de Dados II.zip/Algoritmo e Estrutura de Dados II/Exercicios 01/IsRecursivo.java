class IsRecursivo
{
   public static boolean isFim (String palavra)
   {
      return (palavra.length() >= 3 && palavra.charAt(0) == 'F' && palavra.charAt(1) == 'I' && palavra.charAt(2) == 'M');
   }
   
   public static boolean Vogais (String x,int i)
   {
      boolean resp = true;
      if (i < x.length())
      {
         if ( x.charAt(i) == 'A' || x.charAt(i) == 'E' ||x.charAt(i) == 'I' || x.charAt(i) == 'O' || x.charAt(i)== 'U'|| x.charAt(i) == 'a'||
         x.charAt(i)== 'e' || x.charAt(i) == 'i'||x.charAt(i) == 'o'||x.charAt(i)== 'u')
         {
         resp = true;
         return Vogais(x,++i);    
         }
         else
         {
            return false;
         }
      }
      return resp;
   }

   public static boolean Consoantes (String x,int i)
   {
   boolean resp = true;
      if (i < x.length())
      {
         if (  x.charAt(i) >= '0' && x.charAt(i) <= '9' || x.charAt(i) == 'A' || x.charAt(i) == 'E' || 
         x.charAt(i) == 'I' ||x.charAt(i) == 'O' || x.charAt(i)== 'U'|| x.charAt(i) == 'a'||
         x.charAt(i)== 'e' || x.charAt(i) == 'i'|| x.charAt(i) == 'o'||x.charAt(i) == 'u')
         {
           return resp = false;
         }
         else
         {
         return Consoantes(x,++i);
         }
      }
      return resp;
   }

   public static boolean Inteiro (String x,int i)
   {
      boolean resp = true;
      if (i < x.length())
      {
          if ( x.charAt(i) >= 'a' && x.charAt(i) <= 'z' || x.charAt(i) >= 'A' && x.charAt(i) <= 'Z')
         {
           return resp = false; 
         }
         
         if (x.charAt(i) == ',' ||  x.charAt(i) == '.' ||  x.charAt(i) == ';' ||  x.charAt(i) == ':'||  x.charAt(i) == '-'||
         x.charAt(i) == '('||x.charAt(i) == ')'||x.charAt(i) == '_'|| x.charAt(i) == '?')
         {
            return resp = false;
         }
         if ( x.charAt(i) >= '0' && x.charAt(i) <= '9')
         {
            
            return Inteiro(x,++i);
         }
      }
      return resp;
   }
   
   public static boolean numReal (String x,int i,int virg,int ponto)
   {    
      boolean resp = true;
      if (i < x.length())
      {
         if ( x.charAt(i) >= 'a' && x.charAt(i) <= 'z' || x.charAt(i) >= 'A' && x.charAt(i) <= 'Z')
         {
           return resp = false; 
         }
      //Se o numero tiver mais de uma virgula ou ponto sera considerado falso
         if ( x.charAt(i) == '.' || x.charAt(i) == ',')
         {
            virg ++;   
            ponto ++;
         }
         if ( virg >= 2 || ponto >= 2)
         {
            return resp = false;
         }
         return numReal(x,++i,virg,ponto);
      }
      return resp;
   }
   
   public static void method01 ( )
   {
      boolean resp;
      String[] palavra = new String [1000];
      int numEntrada = 0;
      //Leitura da entrada padrao
   
      do
      {
         palavra[numEntrada] = MyIO.readLine();
      }
      while (isFim(palavra[numEntrada++]) == false);
      numEntrada--;   //Desconsiderar ultima linha contendo a palavra FIM
      
      //Mostrar resultados na tela
      for(int i = 0; i < numEntrada; i++)
      {
         resp = Vogais(palavra[i],0);
         if ( resp == true)
         {
            MyIO.print("SIM ");
         }
         else
         {
            MyIO.print("NAO ");
         }
         resp = Consoantes(palavra[i],0);
         if ( resp == true)
         {
            MyIO.print("SIM ");
         }
         else
         {
            MyIO.print("NAO ");
         }
         resp = Inteiro(palavra[i],0);
         if ( resp == true)
         {
            MyIO.print("SIM ");
         }
         else
         {
            MyIO.print("NAO ");
         }
         resp = numReal(palavra[i],0,0,0);
         if ( resp == true)
         {
            MyIO.print("SIM\n");
         }
         else
         {
            MyIO.print("NAO\n");
         }    
      }
   }

   public static void main (String[] args)
   {
      method01();
   }
}


