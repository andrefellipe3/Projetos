#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define bool short
#define true 1
#define false 0
#define equals(a,b) (((strcmp(a,b) = 0) ? true : false))
#define NUMENTRADA 1000
#define TAMLINHA 1000

bool Fim(char*palavra){
   return (strlen(palavra) >= 3 && palavra[0] == 'F' && palavra[1] == 'I' && palavra[2] == 'M');
}

//Funcao pra retornar a string com a alteracao aleatoria
char *alterar(char palavra[100],char resultado[100],char y,char x,int i)
{
   if ( i < strlen(palavra)-1)
   {
      if ( palavra[i] == x)
      {
     
         palavra[i] = y;
      }
      else
      {
         palavra[i] = palavra[i];
      }
      palavra = alterar(palavra,resultado,x,y,++i);
   }
   return palavra;
}
 
 //Funcao pra gerar um caractere aleatorio
char getRandom()
{
   char random = ((char)('a' +rand()%26));
   return random;
}


void method01 ( )
{
   srand(4);
   int numentrada = 0;
   char palavra[NUMENTRADA][TAMLINHA];
   char*resultado;     
   do
   {
       //Entrada padrao
      fgets(palavra[numentrada],TAMLINHA,stdin);    
   }
      while (Fim(palavra[numentrada++]) == false);
   numentrada--;
   int i = 0;
   //La�o para impressao
   for ( i = 0; i < numentrada; i++)
   { 
      char x;
      char y;
      x = getRandom();
      y = getRandom();
      resultado = alterar(palavra[i],resultado,x,y,0);
      printf("%s",resultado);
   }
}



int main (int argc,char**argv )
{
   method01();
}