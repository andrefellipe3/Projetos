#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#define NUMENTRADA 1000
#define TAMLINHA 1000



void method01 ( )
{
   int quantidade = 0, y = 0,tamanho = 0;
   int countBytes = 0;
   int array [80];
   float numreal = 0;
   scanf("%d",&quantidade);
   FILE*arquivo1 = fopen ("ArquivoC.TXT","wb");
   for ( y = 0; y < quantidade; y++)
   {
      scanf("%f",&numreal);
      fwrite(&numreal,4,quantidade*4,arquivo1);
   }
   fclose (arquivo1);
   //Lendo o arquivo
   arquivo1 = fopen("ArquivoC.TXT","rb");
   fseek(arquivo1, 0, SEEK_END);
   tamanho = ftell(arquivo1);
   countBytes = tamanho/quantidade;
   printf("Tamanho:%d\n",tamanho);
   printf("CountBytes:%d\n",countBytes);
   for ( y = 0; y < quantidade; y++)
   {
      fread(&array[y],countBytes,quantidade*countBytes,arquivo1);
      printf("%g\n",array[y]);
      fseek(arquivo1, -48, SEEK_CUR);
   }
   fclose(arquivo1);
 

}
 


int main (int argc,char**argv)
{
   method01();
   return 0;
}