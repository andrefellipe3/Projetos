class PalindromoRecursivo
{

   public static boolean Fim( String s )
   {
      return (s.length() >= 3 && s.charAt(0)=='F' &&
         s.charAt(1)=='I'&&s.charAt(2)=='M');
   }
   
   public static boolean testePalindromo (String palavra,int i,int x)
   {    
      //Condicao pra retornar true
      if (i >= palavra.length())
      {
      return true;
      }

          //Teste pra descobrir se a String e palindromo ou nao.
         if ( palavra.charAt(i) != palavra.charAt(x))
         {
            return false;
         }
              
         return testePalindromo(palavra,++i,--x);
   }


   public static void method01 ( )
   {
      String[] palavra = new String[1000];
      String[] resposta = new String[1000];
      int numentrada = 0,y = 0,tamanho = 0;
      boolean resultado = true;
      do
      {
         palavra[numentrada] = MyIO.readLine();
         tamanho = palavra[numentrada].length()-1;
         resultado = testePalindromo(palavra[numentrada],0,tamanho);
         if (resultado == false)
         {
            resposta[numentrada] = "NAO";
         }
         else
         {
            resposta[numentrada] = "SIM";
         }
      }
      while (Fim(palavra[numentrada++]) == false);
      numentrada--;   
      
      for ( y = 0; y < numentrada; y++)
      {
         MyIO.println(" "+resposta[y]);
      }
   }
      
   public static void main (String args[])
   {
      method01( );
   }
}