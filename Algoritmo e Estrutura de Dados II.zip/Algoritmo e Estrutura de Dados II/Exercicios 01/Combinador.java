class Combinador
{

   public static boolean isFim (String s)
   {
      return(s.length() >= 3 && s.charAt(0)=='F' &&
         s.charAt(1)=='I'&&s.charAt(2)=='M');
   }

   public static String combinador (String palavra2,String palavra3)
   {
      String resultado = " "; 
      int i = 0, x = 0;
      
      //Se a primeira string for maior que a segunda ele vai usar a primeira como condicao de parada
      if ( palavra2.length() > palavra3.length())
      {
      while (i < palavra2.length())
      {
         if ( i < palavra2.length())
         {
            
            resultado = resultado+palavra2.charAt(i);
            i++;
         }
         if ( x < palavra3.length())
         {
            resultado = resultado+palavra3.charAt(x);
            x++;
         }
      }
      }
       //Se nao, ele vai usar a segunda string como condicao de parada
      else
      {  
      while (i < palavra3.length())
      {
         if ( i < palavra2.length())
         {
            
            resultado = resultado+palavra2.charAt(i);
            i++;
         }
         if ( x < palavra3.length())
         {
            resultado = resultado+palavra3.charAt(x);
            x++;
         }
      }
      }
      return resultado;
   }


   public static void method01 ( )
   {
      String[] palavra1 = new String [1000];
      String[] resultado = new String [1000];
      int numEntrada = 0;
      do
      {
      String palavra2 = " ";
      String palavra3 = " ";
         palavra1[numEntrada] = MyIO.readLine();
         //Separando a primeira string da segunda
         for (int y = 0; y < palavra1[numEntrada].length(); y++)
         {      
            if (palavra1[numEntrada].charAt(y) == ' ')
            {
               y = palavra1[numEntrada].length()-1;
            }
            else
            {
               palavra2 = palavra2 + palavra1[numEntrada].charAt(y);
               
            
            }
         }
         //Separando a segunda string da primeira
         for (int y = 0; y < palavra1[numEntrada].length(); y++)
         {
         
            if (palavra1[numEntrada].charAt(y) == ' ')
            {
            y++;
               while ( y < palavra1[numEntrada].length())
               {                 
                  palavra3 = palavra3+palavra1[numEntrada].charAt(y);          
                  y++;
               }
            }
         }
      
         resultado[numEntrada] = combinador(palavra2,palavra3);
      }
      while(isFim(palavra1[numEntrada++]) == false);
      numEntrada--;
       //La�o para impressao
      for(int i = 0; i < numEntrada; i++)
      {
         MyIO.println(resultado[i]);
      }
   }


   public static void main ( String args[])
   {
      method01();
   }
}