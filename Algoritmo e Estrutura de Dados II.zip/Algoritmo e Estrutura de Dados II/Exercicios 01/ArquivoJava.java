import java.io.*;
import java.text.DecimalFormat;
class ArquivoJava {
   

   public static void main (String[] args) throws Exception
   { 
      DecimalFormat df = new DecimalFormat ("0.####");
      RandomAccessFile raf = new RandomAccessFile("Arquivo.txt", "rw");
      int quantidade = 0;
      long countBytes = 0;
      double numreal = 0;
      quantidade = MyIO.readInt();
   
      for ( int i = 0; i < quantidade; i++)
      {
         numreal = MyIO.readDouble();
         raf.writeDouble(numreal);
         //Salvando 8 bits de cada float
         countBytes = countBytes + 8;
      }
      countBytes = countBytes - 8;
   
   
      while (countBytes >= 0)
      {
        String number = "";
         //Reposicionando o ponteiro no arquivo
         raf.seek(countBytes);
         number = (df.format(raf.readDouble()));
         for ( int i = 0; i < number.length(); i++)
         {
         if (number.charAt(i) == ',')
         {
         number = number.replace(',','.');
         }
         }
        MyIO.println(number);
        // System.out.println(df.format(raf.readDouble()));
         countBytes = countBytes - 8;
      }
      raf.close();
   
   }
}