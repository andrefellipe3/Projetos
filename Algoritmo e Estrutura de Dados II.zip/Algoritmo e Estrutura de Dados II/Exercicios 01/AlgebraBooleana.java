class AlgebraBooleana
{

   public static boolean isFim (String s)
   {
      return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
   }


   //Funcao pra remover os paranteses,virgula e espaco
   public static String parentesesRemove(String s)
   {
      String tmp = "",tmp2 = "",tmp3 = "",vazio = "";
      for (int i = 0; i < s.length(); i++)
      {
         if (s.charAt(i) == '(' || s.charAt(i) == ')')
         {
            tmp = tmp + vazio;
         }
         else
         {
            tmp = tmp + s.charAt(i);
         }
      }
   
      for (int i = 0; i < tmp.length(); i++)
      {
         if (tmp.charAt(i) == ' ')
         {
            tmp2 = tmp2 + vazio;
         }
         else
         {
            tmp2 = tmp2 + tmp.charAt(i);
         }
      }
   
      for (int i = 0; i < tmp2.length(); i++)
      {
         if (tmp2.charAt(i) == ',')
         {
            tmp3 = tmp3 + vazio;
         }
         else
         {
            tmp3 = tmp3 + tmp2.charAt(i);
         }
      }
      return tmp3;
   }
   
   
   //Funcao pra alterar as letras em valores booleano
   public static String substituir (String s)
   {
      String resultado = "";
      String tmp = "",Zero = "0",Um = "1";
   
      if (s.charAt(0) == '2' && s.charAt(2) == '0' && s.charAt(4) == '0')
      {
         for (int i = 5; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Zero;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Zero;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
   
      if (s.charAt(0) == '2' && s.charAt(2) == '0' && s.charAt(4) == '1')
      {
         for (int i = 5; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Zero;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Um;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
   
      if (s.charAt(0) == '2' && s.charAt(2) == '1' && s.charAt(4) == '0')
      {
         for (int i = 5; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Um;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Zero;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
   
      if (s.charAt(0) == '2' && s.charAt(2) == '1' && s.charAt(4) == '1')
      {
         for (int i = 5; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Um;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Um;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
   
      if (s.charAt(0) == '3' && s.charAt(2) == '0' && s.charAt(4) == '0' && s.charAt(6) == '0')
      {
         for (int i = 7; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Zero;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Zero;
               i++;
            }
            if (s.charAt(i) == 'C')
            {
               tmp = tmp + Zero;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
   
      if (s.charAt(0) == '3' && s.charAt(2) == '0' && s.charAt(4) == '0' && s.charAt(6) == '1')
      {
         for (int i = 7; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Zero;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Zero;
               i++;
            }
            if (s.charAt(i) == 'C')
            {
               tmp = tmp + Um;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
   
      if (s.charAt(0) == '3' && s.charAt(2) == '0' && s.charAt(4) == '1' && s.charAt(6) == '0')
      {
         for (int i = 7; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Zero;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Um;
               i++;
            }
            if (s.charAt(i) == 'C')
            {
               tmp = tmp + Zero;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
   
      if (s.charAt(0) == '3' && s.charAt(2) == '0' && s.charAt(4) == '1' && s.charAt(6) == '1')
      {
         for (int i = 7; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Zero;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Um;
               i++;
            }
            if (s.charAt(i) == 'C')
            {
               tmp = tmp + Um;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
   
      if (s.charAt(0) == '3' && s.charAt(2) == '1' && s.charAt(4) == '0' && s.charAt(6) == '0')
      {
         for (int i = 7; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Um;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Zero;
               i++;
            }
            if (s.charAt(i) == 'C')
            {
               tmp = tmp + Zero;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
   
      if (s.charAt(0) == '3' && s.charAt(2) == '1' && s.charAt(4) == '0' && s.charAt(6) == '1')
      {
         for (int i = 7; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Um;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Zero;
               i++;
            }
            if (s.charAt(i) == 'C')
            {
               tmp = tmp + Um;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
   
      if (s.charAt(0) == '3' && s.charAt(2) == '1' && s.charAt(4) == '1' && s.charAt(6) == '0')
      {
         for (int i = 7; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Um;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Um;
               i++;
            }
            if (s.charAt(i) == 'C')
            {
               tmp = tmp + Zero;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
   
      if (s.charAt(0) == '3' && s.charAt(2) == '1' && s.charAt(4) == '1' && s.charAt(6) == '1')
      {
         for (int i = 7; i < s.length(); i++)
         {
            if (s.charAt(i) == 'A')
            {
               tmp = tmp + Um;
               i++;
            }
            if (s.charAt(i) == 'B')
            {
               tmp = tmp + Um;
               i++;
            }
            if (s.charAt(i) == 'C')
            {
               tmp = tmp + Um;
               i++;
            }
            tmp = tmp + s.charAt(i);
         }
         return resultado = tmp;
      }
      return resultado;
   }

   public static String And(String s)
   {
       
      String tmp = "";
      String zero = "0";
      String um = "1";
  
      for ( int i = 0; i < s.length(); i++)
      {
      //and(0,0)
         if(s.charAt(i) == 'a' && s.charAt(i+1) == 'n' && s.charAt(i+2) == 'd' && s.charAt(i+3) == '0' && s.charAt(i+4) == '0')
         {
            tmp = tmp + zero;
            i = i + 4;           
         }
      
      //and(1,0)
         if(s.charAt(i) == 'a' && s.charAt(i+1) == 'n' && s.charAt(i+2) == 'd' && s.charAt(i+3) == '1' && s.charAt(i+4) == '0')
         {
            tmp = tmp + zero;
            i = i + 4;
         }
      
      //and(0,1)
         if(s.charAt(i) == 'a' && s.charAt(i+1) == 'n' && s.charAt(i+2) == 'd' && s.charAt(i+3) == '0' && s.charAt(i+4) == '1')
         {
            tmp = tmp + zero;
            i = i + 4;
         }
      
      //and(1,1)
         if(s.charAt(i) == 'a' && s.charAt(i+1) == 'n' && s.charAt(i+2) == 'd' && s.charAt(i+3) == '1' && s.charAt(i+4) == '1')
         {
            tmp = tmp + um;
            i = i + 4;
         }
      
      //and(1,1,1)
         if(s.charAt(i) == 'a' && s.charAt(i+1) == 'n' && s.charAt(i+2) == 'd' && s.charAt(i+3) == '1' && s.charAt(i+4) == '1'
         && s.charAt(i+5) == '1')
         {
            tmp = tmp + um;
            i = i + 5;
         }
      
      //and(1,1,0)
         if(s.charAt(i) == 'a' && s.charAt(i+1) == 'n' && s.charAt(i+2) == 'd' && s.charAt(i+3) == '1' && s.charAt(i+4) == '1'
         && s.charAt(i+5) == '0')
         {
            tmp = tmp + zero;
            i = i + 5;
         }
      
      //and(1,0,1)
         if(s.charAt(i) == 'a' && s.charAt(i+1) == 'n' && s.charAt(i+2) == 'd' && s.charAt(i+3) == '1' && s.charAt(i+4) == '0'
         && s.charAt(i+5) == '1')
         {
            tmp = tmp + zero;
            i = i + 5;
         }
      
      //and(1,0,0)
         if(s.charAt(i) == 'a' && s.charAt(i+1) == 'n' && s.charAt(i+2) == 'd' && s.charAt(i+3) == '1' && s.charAt(i+4) == '0'
         && s.charAt(i+5) == '0')
         {
            tmp = tmp + zero;
            i = i + 5;
         }
      
      //and(0,0,1)
         if(s.charAt(i) == 'a' && s.charAt(i+1) == 'n' && s.charAt(i+2) == 'd' && s.charAt(i+3) == '0' && s.charAt(i+4) == '0'
         && s.charAt(i+5) == '1')
         {
            tmp = tmp + zero;
            i = i + 5;
         }
      
      //and(0,0,0)
         if(s.charAt(i) == 'a' && s.charAt(i+1) == 'n' && s.charAt(i+2) == 'd' && s.charAt(i+3) == '0' && s.charAt(i+4) == '0'
         && s.charAt(i+5) == '0')
         {
            tmp = tmp + zero;
            i = i + 5;
         }
      
      //and(0,1,0)
         if(s.charAt(i) == 'a' && s.charAt(i+1) == 'n' && s.charAt(i+2) == 'd' && s.charAt(i+3) == '0' && s.charAt(i+4) == '1'
         && s.charAt(i+5) == '0')
         {
            tmp = tmp + zero;
            i = i + 5;
         }
         if (i < s.length()-1)
         {
         tmp = tmp + s.charAt(i);
         }
      }
      return tmp; 
   }
   
   public static String Or(String s)
   {
      String tmp = "",tmp1 = "";
      String zero = "0";
      String um = "1";

      for ( int i = 0; i < s.length(); i++)
      {
      //or(0,0)
         if(s.charAt(i) == 'o' && s.charAt(i+1) == 'r' && s.charAt(i+2) == '0' && s.charAt(i+3) == '0')
         {
            tmp = tmp + zero;
            i = i +3;
         }
      
      //or(0,1)
         if(s.charAt(i) == 'o' && s.charAt(i+1) == 'r' && s.charAt(i+2) == '0' && s.charAt(i+3) == '1')
         {
            tmp = tmp + um;
            i = i +3;
         }
      
      //or(1,1)
         if(s.charAt(i) == 'o' && s.charAt(i+1) == 'r' && s.charAt(i+2) == '1' && s.charAt(i+3) == '1')
         {
            tmp = tmp + um;
            i = i +3;
         }
      
      //or(1,0)
         if(s.charAt(i) == 'o' && s.charAt(i+1) == 'r' && s.charAt(i+2) == '1' && s.charAt(i+3) == '0')
         {
            tmp = tmp + um;
            i = i +3;
         }
         if (i < s.length()-1)
         {
         tmp = tmp + s.charAt(i);
         }
      }  
      return tmp; 
   }
   
   public static String Not(String s)
   {
          
      String tmp = "";
      String zero = "0";
      String um = "1";
   
      for ( int i = 0; i < s.length(); i++)
      {
      //not(0)
         if(s.charAt(i) == 'n' && s.charAt(i+1) == 'o' && s.charAt(i+2) == 't' && s.charAt(i+3) == '0')
         {
            tmp = tmp + um;
            i = i +3;
         }
      
      //not(1)
         if(s.charAt(i) == 'n' && s.charAt(i+1) == 'o' && s.charAt(i+2) == 't' && s.charAt(i+3) == '1')
         {
            tmp = tmp + zero;
            i = i +3;
         }
         if (i < s.length()-1)
         {
         tmp = tmp + s.charAt(i);
         }
      }  
      return tmp; 
   }
   
   
   public static void method01 ( )
   {
      int numEntrada = 0;
      String[] algebra = new String[1000];
      do
      {
         String resposta = "";
          
         algebra[numEntrada] = MyIO.readLine();
         resposta = substituir(algebra[numEntrada]);
         resposta = parentesesRemove(resposta);
         MyIO.println(resposta);
         if ( resposta.charAt(0) == 'a' && resposta.charAt(1) == 'n' && resposta.charAt(2) == 'd')
         {
            MyIO.println("Primeiro if");
            resposta = Not(resposta);
            MyIO.println(resposta);
            resposta = Or(resposta);
            MyIO.println(resposta);
            resposta = And(resposta); 
         }
         if ( resposta.charAt(0) == 'n' && resposta.charAt(1) == 'o' && resposta.charAt(2) == 't')
         {
            MyIO.println("Segundo if");
            resposta = And(resposta);
            if (resposta.charAt(0) == 'o' && resposta.charAt(1) == 'r')
            {
            resposta = Or(resposta);
            }
            resposta = Not(resposta);
         }
         if ( resposta.charAt(0) == 'o' && resposta.charAt(1) == 'r')
         {
            MyIO.println("Terceiro if");
            resposta = Not(resposta);
            resposta = And(resposta);
            resposta = Or(resposta);
         }
         MyIO.println(resposta);
      }
      while (isFim(algebra[numEntrada++]) == false);
   }


   public static void main (String args[])
   {
      method01();
   
   }
}