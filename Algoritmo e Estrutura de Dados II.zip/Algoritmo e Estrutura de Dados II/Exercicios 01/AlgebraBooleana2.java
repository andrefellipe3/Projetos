class AlgebraBooleana
{

   public static boolean isFim (String s)
   {
      return (s.length() >= 3 && s.charAt(0) == 'F' && s.charAt(1) == 'I' && s.charAt(2) == 'M');
   }



   
   public static void method01 ( )
   {
      int numEntrada = 0;
      String[] algebra = new String[1000];
      do
      {
         String resposta = "";
          
         algebra[numEntrada] = MyIO.readLine();
         resposta = substituir(algebra[numEntrada]);
         resposta = parentesesRemove(resposta);
         resposta = resolverEquacao(resposta);
         MyIO.println(resposta);
      }
      while (isFim(algebra[numEntrada++]) == false);
   }


   public static void main (String args[])
   {
      method01();
   
   }
}