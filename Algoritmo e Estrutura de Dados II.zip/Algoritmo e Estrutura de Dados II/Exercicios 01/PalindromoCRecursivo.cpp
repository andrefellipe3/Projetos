#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#define NUMENTRADA 1000
#define TAMLINHA 1000


bool Fim(char*palavra){
   return (strlen(palavra) >= 3 && palavra[0] == 'F' && palavra[1] == 'I' && palavra[2] == 'M');
}

bool palindromo (char*palavra,int i,int x)
{     
    //Se conseguir ler a palavra toda e true
    if (i >= strlen(palavra)-1)
    {
    return true;
    }  
      //Teste pra saber se a palavra � um palindromo
      if (palavra[i] != palavra[x])
      {
         return false;
      }
    return palindromo(palavra,++i,--x);
}


void method01 ( )
{
   char palavra[NUMENTRADA][TAMLINHA];   
   int numentrada = 0,y = 0,x = 0;
   bool resultado = true;
   do
   {
      //Entrada padrao
      fgets(palavra[numentrada],TAMLINHA,stdin);
      x = strlen(palavra[numentrada])-2;
      resultado = palindromo(palavra[numentrada],0,x);
      
      if (Fim(palavra[numentrada]) == true)
      {
      printf(" ");
      }
      
      else if (resultado == true)
      {  
         printf("SIM\n");
      }
      
      else
      {
         printf("NAO\n");
      }
   }
      while (Fim(palavra[numentrada++]) == false);
   numentrada--;   
}

int main (int argc,char**argv )
{
   method01();
}